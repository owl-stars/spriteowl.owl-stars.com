/*! JSON v3.3.0 | http://bestiejs.github.io/json3 | Copyright 2012-2014, Kit Cambridge | http://kit.mit-license.org */
;(function (root) {
  // Detect the `define` function exposed by asynchronous module loaders. The
  // strict `define` check is necessary for compatibility with `r.js`.
  var isLoader = typeof define === "function" && define.amd;

  // Use the `global` object exposed by Node (including Browserify via
  // `insert-module-globals`), Narwhal, and Ringo as the default context.
  // Rhino exports a `global` function instead.
  var freeGlobal = typeof global == "object" && global;
  if (freeGlobal && (freeGlobal["global"] === freeGlobal || freeGlobal["window"] === freeGlobal)) {
    root = freeGlobal;
  }

  // Public: Initializes JSON 3 using the given `context` object, attaching the
  // `stringify` and `parse` functions to the specified `exports` object.
  function runInContext(context, exports) {
    context || (context = root["Object"]());
    exports || (exports = root["Object"]());

    // Native constructor aliases.
    var Number = context["Number"] || root["Number"],
        String = context["String"] || root["String"],
        Object = context["Object"] || root["Object"],
        Date = context["Date"] || root["Date"],
        SyntaxError = context["SyntaxError"] || root["SyntaxError"],
        TypeError = context["TypeError"] || root["TypeError"],
        Math = context["Math"] || root["Math"],
        nativeJSON = context["JSON"] || root["JSON"];

    // Delegate to the native `stringify` and `parse` implementations.
    if (typeof nativeJSON == "object" && nativeJSON) {
      exports.stringify = nativeJSON.stringify;
      exports.parse = nativeJSON.parse;
    }

    // Convenience aliases.
    var objectProto = Object.prototype,
        getClass = objectProto.toString,
        isProperty, forEach, undef;

    // Test the `Date#getUTC*` methods. Based on work by @Yaffle.
    var isExtended = new Date(-3509827334573292);
    try {
      // The `getUTCFullYear`, `Month`, and `Date` methods return nonsensical
      // results for certain dates in Opera >= 10.53.
      isExtended = isExtended.getUTCFullYear() == -109252 && isExtended.getUTCMonth() === 0 && isExtended.getUTCDate() === 1 &&
        // Safari < 2.0.2 stores the internal millisecond time value correctly,
        // but clips the values returned by the date methods to the range of
        // signed 32-bit integers ([-2 ** 31, 2 ** 31 - 1]).
        isExtended.getUTCHours() == 10 && isExtended.getUTCMinutes() == 37 && isExtended.getUTCSeconds() == 6 && isExtended.getUTCMilliseconds() == 708;
    } catch (exception) {}

    // Internal: Determines whether the native `JSON.stringify` and `parse`
    // implementations are spec-compliant. Based on work by Ken Snyder.
    function has(name) {
      if (has[name] !== undef) {
        // Return cached feature test result.
        return has[name];
      }
      var isSupported;
      if (name == "bug-string-char-index") {
        // IE <= 7 doesn't support accessing string characters using square
        // bracket notation. IE 8 only supports this for primitives.
        isSupported = "a"[0] != "a";
      } else if (name == "json") {
        // Indicates whether both `JSON.stringify` and `JSON.parse` are
        // supported.
        isSupported = has("json-stringify") && has("json-parse");
      } else {
        var value, serialized = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
        // Test `JSON.stringify`.
        if (name == "json-stringify") {
          var stringify = exports.stringify, stringifySupported = typeof stringify == "function" && isExtended;
          if (stringifySupported) {
            // A test function object with a custom `toJSON` method.
            (value = function () {
              return 1;
            }).toJSON = value;
            try {
              stringifySupported =
                // Firefox 3.1b1 and b2 serialize string, number, and boolean
                // primitives as object literals.
                stringify(0) === "0" &&
                // FF 3.1b1, b2, and JSON 2 serialize wrapped primitives as object
                // literals.
                stringify(new Number()) === "0" &&
                stringify(new String()) == '""' &&
                // FF 3.1b1, 2 throw an error if the value is `null`, `undefined`, or
                // does not define a canonical JSON representation (this applies to
                // objects with `toJSON` properties as well, *unless* they are nested
                // within an object or array).
                stringify(getClass) === undef &&
                // IE 8 serializes `undefined` as `"undefined"`. Safari <= 5.1.7 and
                // FF 3.1b3 pass this test.
                stringify(undef) === undef &&
                // Safari <= 5.1.7 and FF 3.1b3 throw `Error`s and `TypeError`s,
                // respectively, if the value is omitted entirely.
                stringify() === undef &&
                // FF 3.1b1, 2 throw an error if the given value is not a number,
                // string, array, object, Boolean, or `null` literal. This applies to
                // objects with custom `toJSON` methods as well, unless they are nested
                // inside object or array literals. YUI 3.0.0b1 ignores custom `toJSON`
                // methods entirely.
                stringify(value) === "1" &&
                stringify([value]) == "[1]" &&
                // Prototype <= 1.6.1 serializes `[undefined]` as `"[]"` instead of
                // `"[null]"`.
                stringify([undef]) == "[null]" &&
                // YUI 3.0.0b1 fails to serialize `null` literals.
                stringify(null) == "null" &&
                // FF 3.1b1, 2 halts serialization if an array contains a function:
                // `[1, true, getClass, 1]` serializes as "[1,true,],". FF 3.1b3
                // elides non-JSON values from objects and arrays, unless they
                // define custom `toJSON` methods.
                stringify([undef, getClass, null]) == "[null,null,null]" &&
                // Simple serialization test. FF 3.1b1 uses Unicode escape sequences
                // where character escape codes are expected (e.g., `\b` => `\u0008`).
                stringify({ "a": [value, true, false, null, "\x00\b\n\f\r\t"] }) == serialized &&
                // FF 3.1b1 and b2 ignore the `filter` and `width` arguments.
                stringify(null, value) === "1" &&
                stringify([1, 2], null, 1) == "[\n 1,\n 2\n]" &&
                // JSON 2, Prototype <= 1.7, and older WebKit builds incorrectly
                // serialize extended years.
                stringify(new Date(-8.64e15)) == '"-271821-04-20T00:00:00.000Z"' &&
                // The milliseconds are optional in ES 5, but required in 5.1.
                stringify(new Date(8.64e15)) == '"+275760-09-13T00:00:00.000Z"' &&
                // Firefox <= 11.0 incorrectly serializes years prior to 0 as negative
                // four-digit years instead of six-digit years. Credits: @Yaffle.
                stringify(new Date(-621987552e5)) == '"-000001-01-01T00:00:00.000Z"' &&
                // Safari <= 5.1.5 and Opera >= 10.53 incorrectly serialize millisecond
                // values less than 1000. Credits: @Yaffle.
                stringify(new Date(-1)) == '"1969-12-31T23:59:59.999Z"';
            } catch (exception) {
              stringifySupported = false;
            }
          }
          isSupported = stringifySupported;
        }
        // Test `JSON.parse`.
        if (name == "json-parse") {
          var parse = exports.parse;
          if (typeof parse == "function") {
            try {
              // FF 3.1b1, b2 will throw an exception if a bare literal is provided.
              // Conforming implementations should also coerce the initial argument to
              // a string prior to parsing.
              if (parse("0") === 0 && !parse(false)) {
                // Simple parsing test.
                value = parse(serialized);
                var parseSupported = value["a"].length == 5 && value["a"][0] === 1;
                if (parseSupported) {
                  try {
                    // Safari <= 5.1.2 and FF 3.1b1 allow unescaped tabs in strings.
                    parseSupported = !parse('"\t"');
                  } catch (exception) {}
                  if (parseSupported) {
                    try {
                      // FF 4.0 and 4.0.1 allow leading `+` signs and leading
                      // decimal points. FF 4.0, 4.0.1, and IE 9-10 also allow
                      // certain octal literals.
                      parseSupported = parse("01") !== 1;
                    } catch (exception) {}
                  }
                  if (parseSupported) {
                    try {
                      // FF 4.0, 4.0.1, and Rhino 1.7R3-R4 allow trailing decimal
                      // points. These environments, along with FF 3.1b1 and 2,
                      // also allow trailing commas in JSON objects and arrays.
                      parseSupported = parse("1.") !== 1;
                    } catch (exception) {}
                  }
                }
              }
            } catch (exception) {
              parseSupported = false;
            }
          }
          isSupported = parseSupported;
        }
      }
      return has[name] = !!isSupported;
    }

    if (!has("json")) {
      // Common `[[Class]]` name aliases.
      var functionClass = "[object Function]",
          dateClass = "[object Date]",
          numberClass = "[object Number]",
          stringClass = "[object String]",
          arrayClass = "[object Array]",
          booleanClass = "[object Boolean]";

      // Detect incomplete support for accessing string characters by index.
      var charIndexBuggy = has("bug-string-char-index");

      // Define additional utility methods if the `Date` methods are buggy.
      if (!isExtended) {
        var floor = Math.floor;
        // A mapping between the months of the year and the number of days between
        // January 1st and the first of the respective month.
        var Months = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        // Internal: Calculates the number of days between the Unix epoch and the
        // first day of the given month.
        var getDay = function (year, month) {
          return Months[month] + 365 * (year - 1970) + floor((year - 1969 + (month = +(month > 1))) / 4) - floor((year - 1901 + month) / 100) + floor((year - 1601 + month) / 400);
        };
      }

      // Internal: Determines if a property is a direct property of the given
      // object. Delegates to the native `Object#hasOwnProperty` method.
      if (!(isProperty = objectProto.hasOwnProperty)) {
        isProperty = function (property) {
          var members = {}, constructor;
          if ((members.__proto__ = null, members.__proto__ = {
            // The *proto* property cannot be set multiple times in recent
            // versions of Firefox and SeaMonkey.
            "toString": 1
          }, members).toString != getClass) {
            // Safari <= 2.0.3 doesn't implement `Object#hasOwnProperty`, but
            // supports the mutable *proto* property.
            isProperty = function (property) {
              // Capture and break the objectgs prototype chain (see section 8.6.2
              // of the ES 5.1 spec). The parenthesized expression prevents an
              // unsafe transformation by the Closure Compiler.
              var original = this.__proto__, result = property in (this.__proto__ = null, this);
              // Restore the original prototype chain.
              this.__proto__ = original;
              return result;
            };
          } else {
            // Capture a reference to the top-level `Object` constructor.
            constructor = members.constructor;
            // Use the `constructor` property to simulate `Object#hasOwnProperty` in
            // other environments.
            isProperty = function (property) {
              var parent = (this.constructor || constructor).prototype;
              return property in this && !(property in parent && this[property] === parent[property]);
            };
          }
          members = null;
          return isProperty.call(this, property);
        };
      }

      // Internal: A set of primitive types used by `isHostType`.
      var PrimitiveTypes = {
        "boolean": 1,
        "number": 1,
        "string": 1,
        "undefined": 1
      };

      // Internal: Determines if the given object `property` value is a
      // non-primitive.
      var isHostType = function (object, property) {
        var type = typeof object[property];
        return type == "object" ? !!object[property] : !PrimitiveTypes[type];
      };

      // Internal: Normalizes the `for...in` iteration algorithm across
      // environments. Each enumerated key is yielded to a `callback` function.
      forEach = function (object, callback) {
        var size = 0, Properties, members, property;

        // Tests for bugs in the current environment's `for...in` algorithm. The
        // `valueOf` property inherits the non-enumerable flag from
        // `Object.prototype` in older versions of IE, Netscape, and Mozilla.
        (Properties = function () {
          this.valueOf = 0;
        }).prototype.valueOf = 0;

        // Iterate over a new instance of the `Properties` class.
        members = new Properties();
        for (property in members) {
          // Ignore all properties inherited from `Object.prototype`.
          if (isProperty.call(members, property)) {
            size++;
          }
        }
        Properties = members = null;

        // Normalize the iteration algorithm.
        if (!size) {
          // A list of non-enumerable properties inherited from `Object.prototype`.
          members = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"];
          // IE <= 8, Mozilla 1.0, and Netscape 6.2 ignore shadowed non-enumerable
          // properties.
          forEach = function (object, callback) {
            var isFunction = getClass.call(object) == functionClass, property, length;
            var hasProperty = !isFunction && typeof object.constructor != "function" && isHostType(object, "hasOwnProperty") ? object.hasOwnProperty : isProperty;
            for (property in object) {
              // Gecko <= 1.0 enumerates the `prototype` property of functions under
              // certain conditions; IE does not.
              if (!(isFunction && property == "prototype") && hasProperty.call(object, property)) {
                callback(property);
              }
            }
            // Manually invoke the callback for each non-enumerable property.
            for (length = members.length; property = members[--length]; hasProperty.call(object, property) && callback(property));
          };
        } else if (size == 2) {
          // Safari <= 2.0.4 enumerates shadowed properties twice.
          forEach = function (object, callback) {
            // Create a set of iterated properties.
            var members = {}, isFunction = getClass.call(object) == functionClass, property;
            for (property in object) {
              // Store each property name to prevent double enumeration. The
              // `prototype` property of functions is not enumerated due to cross-
              // environment inconsistencies.
              if (!(isFunction && property == "prototype") && !isProperty.call(members, property) && (members[property] = 1) && isProperty.call(object, property)) {
                callback(property);
              }
            }
          };
        } else {
          // No bugs detected; use the standard `for...in` algorithm.
          forEach = function (object, callback) {
            var isFunction = getClass.call(object) == functionClass, property, isConstructor;
            for (property in object) {
              if (!(isFunction && property == "prototype") && isProperty.call(object, property) && !(isConstructor = property === "constructor")) {
                callback(property);
              }
            }
            // Manually invoke the callback for the `constructor` property due to
            // cross-environment inconsistencies.
            if (isConstructor || isProperty.call(object, (property = "constructor"))) {
              callback(property);
            }
          };
        }
        return forEach(object, callback);
      };

      // Public: Serializes a JavaScript `value` as a JSON string. The optional
      // `filter` argument may specify either a function that alters how object and
      // array members are serialized, or an array of strings and numbers that
      // indicates which properties should be serialized. The optional `width`
      // argument may be either a string or number that specifies the indentation
      // level of the output.
      if (!has("json-stringify")) {
        // Internal: A map of control characters and their escaped equivalents.
        var Escapes = {
          92: "\\\\",
          34: '\\"',
          8: "\\b",
          12: "\\f",
          10: "\\n",
          13: "\\r",
          9: "\\t"
        };

        // Internal: Converts `value` into a zero-padded string such that its
        // length is at least equal to `width`. The `width` must be <= 6.
        var leadingZeroes = "000000";
        var toPaddedString = function (width, value) {
          // The `|| 0` expression is necessary to work around a bug in
          // Opera <= 7.54u2 where `0 == -0`, but `String(-0) !== "0"`.
          return (leadingZeroes + (value || 0)).slice(-width);
        };

        // Internal: Double-quotes a string `value`, replacing all ASCII control
        // characters (characters with code unit values between 0 and 31) with
        // their escaped equivalents. This is an implementation of the
        // `Quote(value)` operation defined in ES 5.1 section 15.12.3.
        var unicodePrefix = "\\u00";
        var quote = function (value) {
          var result = '"', index = 0, length = value.length, useCharIndex = !charIndexBuggy || length > 10;
          var symbols = useCharIndex && (charIndexBuggy ? value.split("") : value);
          for (; index < length; index++) {
            var charCode = value.charCodeAt(index);
            // If the character is a control character, append its Unicode or
            // shorthand escape sequence; otherwise, append the character as-is.
            switch (charCode) {
              case 8: case 9: case 10: case 12: case 13: case 34: case 92:
                result += Escapes[charCode];
                break;
              default:
                if (charCode < 32) {
                  result += unicodePrefix + toPaddedString(2, charCode.toString(16));
                  break;
                }
                result += useCharIndex ? symbols[index] : value.charAt(index);
            }
          }
          return result + '"';
        };

        // Internal: Recursively serializes an object. Implements the
        // `Str(key, holder)`, `JO(value)`, and `JA(value)` operations.
        var serialize = function (property, object, callback, properties, whitespace, indentation, stack) {
          var value, className, year, month, date, time, hours, minutes, seconds, milliseconds, results, element, index, length, prefix, result;
          try {
            // Necessary for host object support.
            value = object[property];
          } catch (exception) {}
          if (typeof value == "object" && value) {
            className = getClass.call(value);
            if (className == dateClass && !isProperty.call(value, "toJSON")) {
              if (value > -1 / 0 && value < 1 / 0) {
                // Dates are serialized according to the `Date#toJSON` method
                // specified in ES 5.1 section 15.9.5.44. See section 15.9.1.15
                // for the ISO 8601 date time string format.
                if (getDay) {
                  // Manually compute the year, month, date, hours, minutes,
                  // seconds, and milliseconds if the `getUTC*` methods are
                  // buggy. Adapted from @Yaffle's `date-shim` project.
                  date = floor(value / 864e5);
                  for (year = floor(date / 365.2425) + 1970 - 1; getDay(year + 1, 0) <= date; year++);
                  for (month = floor((date - getDay(year, 0)) / 30.42); getDay(year, month + 1) <= date; month++);
                  date = 1 + date - getDay(year, month);
                  // The `time` value specifies the time within the day (see ES
                  // 5.1 section 15.9.1.2). The formula `(A % B + B) % B` is used
                  // to compute `A modulo B`, as the `%` operator does not
                  // correspond to the `modulo` operation for negative numbers.
                  time = (value % 864e5 + 864e5) % 864e5;
                  // The hours, minutes, seconds, and milliseconds are obtained by
                  // decomposing the time within the day. See section 15.9.1.10.
                  hours = floor(time / 36e5) % 24;
                  minutes = floor(time / 6e4) % 60;
                  seconds = floor(time / 1e3) % 60;
                  milliseconds = time % 1e3;
                } else {
                  year = value.getUTCFullYear();
                  month = value.getUTCMonth();
                  date = value.getUTCDate();
                  hours = value.getUTCHours();
                  minutes = value.getUTCMinutes();
                  seconds = value.getUTCSeconds();
                  milliseconds = value.getUTCMilliseconds();
                }
                // Serialize extended years correctly.
                value = (year <= 0 || year >= 1e4 ? (year < 0 ? "-" : "+") + toPaddedString(6, year < 0 ? -year : year) : toPaddedString(4, year)) +
                  "-" + toPaddedString(2, month + 1) + "-" + toPaddedString(2, date) +
                  // Months, dates, hours, minutes, and seconds should have two
                  // digits; milliseconds should have three.
                  "T" + toPaddedString(2, hours) + ":" + toPaddedString(2, minutes) + ":" + toPaddedString(2, seconds) +
                  // Milliseconds are optional in ES 5.0, but required in 5.1.
                  "." + toPaddedString(3, milliseconds) + "Z";
              } else {
                value = null;
              }
            } else if (typeof value.toJSON == "function" && ((className != numberClass && className != stringClass && className != arrayClass) || isProperty.call(value, "toJSON"))) {
              // Prototype <= 1.6.1 adds non-standard `toJSON` methods to the
              // `Number`, `String`, `Date`, and `Array` prototypes. JSON 3
              // ignores all `toJSON` methods on these objects unless they are
              // defined directly on an instance.
              value = value.toJSON(property);
            }
          }
          if (callback) {
            // If a replacement function was provided, call it to obtain the value
            // for serialization.
            value = callback.call(object, property, value);
          }
          if (value === null) {
            return "null";
          }
          className = getClass.call(value);
          if (className == booleanClass) {
            // Booleans are represented literally.
            return "" + value;
          } else if (className == numberClass) {
            // JSON numbers must be finite. `Infinity` and `NaN` are serialized as
            // `"null"`.
            return value > -1 / 0 && value < 1 / 0 ? "" + value : "null";
          } else if (className == stringClass) {
            // Strings are double-quoted and escaped.
            return quote("" + value);
          }
          // Recursively serialize objects and arrays.
          if (typeof value == "object") {
            // Check for cyclic structures. This is a linear search; performance
            // is inversely proportional to the number of unique nested objects.
            for (length = stack.length; length--;) {
              if (stack[length] === value) {
                // Cyclic structures cannot be serialized by `JSON.stringify`.
                throw TypeError();
              }
            }
            // Add the object to the stack of traversed objects.
            stack.push(value);
            results = [];
            // Save the current indentation level and indent one additional level.
            prefix = indentation;
            indentation += whitespace;
            if (className == arrayClass) {
              // Recursively serialize array elements.
              for (index = 0, length = value.length; index < length; index++) {
                element = serialize(index, value, callback, properties, whitespace, indentation, stack);
                results.push(element === undef ? "null" : element);
              }
              result = results.length ? (whitespace ? "[\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "]" : ("[" + results.join(",") + "]")) : "[]";
            } else {
              // Recursively serialize object members. Members are selected from
              // either a user-specified list of property names, or the object
              // itself.
              forEach(properties || value, function (property) {
                var element = serialize(property, value, callback, properties, whitespace, indentation, stack);
                if (element !== undef) {
                  // According to ES 5.1 section 15.12.3: "If `gap` {whitespace}
                  // is not the empty string, let `member` {quote(property) + ":"}
                  // be the concatenation of `member` and the `space` character."
                  // The "`space` character" refers to the literal space
                  // character, not the `space` {width} argument provided to
                  // `JSON.stringify`.
                  results.push(quote(property) + ":" + (whitespace ? " " : "") + element);
                }
              });
              result = results.length ? (whitespace ? "{\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "}" : ("{" + results.join(",") + "}")) : "{}";
            }
            // Remove the object from the traversed object stack.
            stack.pop();
            return result;
          }
        };

        // Public: `JSON.stringify`. See ES 5.1 section 15.12.3.
        exports.stringify = function (source, filter, width) {
          var whitespace, callback, properties, className;
          if (typeof filter == "function" || typeof filter == "object" && filter) {
            if ((className = getClass.call(filter)) == functionClass) {
              callback = filter;
            } else if (className == arrayClass) {
              // Convert the property names array into a makeshift set.
              properties = {};
              for (var index = 0, length = filter.length, value; index < length; value = filter[index++], ((className = getClass.call(value)), className == stringClass || className == numberClass) && (properties[value] = 1));
            }
          }
          if (width) {
            if ((className = getClass.call(width)) == numberClass) {
              // Convert the `width` to an integer and create a string containing
              // `width` number of space characters.
              if ((width -= width % 1) > 0) {
                for (whitespace = "", width > 10 && (width = 10); whitespace.length < width; whitespace += " ");
              }
            } else if (className == stringClass) {
              whitespace = width.length <= 10 ? width : width.slice(0, 10);
            }
          }
          // Opera <= 7.54u2 discards the values associated with empty string keys
          // (`""`) only if they are used directly within an object member list
          // (e.g., `!("" in { "": 1})`).
          return serialize("", (value = {}, value[""] = source, value), callback, properties, whitespace, "", []);
        };
      }

      // Public: Parses a JSON source string.
      if (!has("json-parse")) {
        var fromCharCode = String.fromCharCode;

        // Internal: A map of escaped control characters and their unescaped
        // equivalents.
        var Unescapes = {
          92: "\\",
          34: '"',
          47: "/",
          98: "\b",
          116: "\t",
          110: "\n",
          102: "\f",
          114: "\r"
        };

        // Internal: Stores the parser state.
        var Index, Source;

        // Internal: Resets the parser state and throws a `SyntaxError`.
        var abort = function () {
          Index = Source = null;
          throw SyntaxError();
        };

        // Internal: Returns the next token, or `"$"` if the parser has reached
        // the end of the source string. A token may be a string, number, `null`
        // literal, or Boolean literal.
        var lex = function () {
          var source = Source, length = source.length, value, begin, position, isSigned, charCode;
          while (Index < length) {
            charCode = source.charCodeAt(Index);
            switch (charCode) {
              case 9: case 10: case 13: case 32:
                // Skip whitespace tokens, including tabs, carriage returns, line
                // feeds, and space characters.
                Index++;
                break;
              case 123: case 125: case 91: case 93: case 58: case 44:
                // Parse a punctuator token (`{`, `}`, `[`, `]`, `:`, or `,`) at
                // the current position.
                value = charIndexBuggy ? source.charAt(Index) : source[Index];
                Index++;
                return value;
              case 34:
                // `"` delimits a JSON string; advance to the next character and
                // begin parsing the string. String tokens are prefixed with the
                // sentinel `@` character to distinguish them from punctuators and
                // end-of-string tokens.
                for (value = "@", Index++; Index < length;) {
                  charCode = source.charCodeAt(Index);
                  if (charCode < 32) {
                    // Unescaped ASCII control characters (those with a code unit
                    // less than the space character) are not permitted.
                    abort();
                  } else if (charCode == 92) {
                    // A reverse solidus (`\`) marks the beginning of an escaped
                    // control character (including `"`, `\`, and `/`) or Unicode
                    // escape sequence.
                    charCode = source.charCodeAt(++Index);
                    switch (charCode) {
                      case 92: case 34: case 47: case 98: case 116: case 110: case 102: case 114:
                        // Revive escaped control characters.
                        value += Unescapes[charCode];
                        Index++;
                        break;
                      case 117:
                        // `\u` marks the beginning of a Unicode escape sequence.
                        // Advance to the first character and validate the
                        // four-digit code point.
                        begin = ++Index;
                        for (position = Index + 4; Index < position; Index++) {
                          charCode = source.charCodeAt(Index);
                          // A valid sequence comprises four hexdigits (case-
                          // insensitive) that form a single hexadecimal value.
                          if (!(charCode >= 48 && charCode <= 57 || charCode >= 97 && charCode <= 102 || charCode >= 65 && charCode <= 70)) {
                            // Invalid Unicode escape sequence.
                            abort();
                          }
                        }
                        // Revive the escaped character.
                        value += fromCharCode("0x" + source.slice(begin, Index));
                        break;
                      default:
                        // Invalid escape sequence.
                        abort();
                    }
                  } else {
                    if (charCode == 34) {
                      // An unescaped double-quote character marks the end of the
                      // string.
                      break;
                    }
                    charCode = source.charCodeAt(Index);
                    begin = Index;
                    // Optimize for the common case where a string is valid.
                    while (charCode >= 32 && charCode != 92 && charCode != 34) {
                      charCode = source.charCodeAt(++Index);
                    }
                    // Append the string as-is.
                    value += source.slice(begin, Index);
                  }
                }
                if (source.charCodeAt(Index) == 34) {
                  // Advance to the next character and return the revived string.
                  Index++;
                  return value;
                }
                // Unterminated string.
                abort();
              default:
                // Parse numbers and literals.
                begin = Index;
                // Advance past the negative sign, if one is specified.
                if (charCode == 45) {
                  isSigned = true;
                  charCode = source.charCodeAt(++Index);
                }
                // Parse an integer or floating-point value.
                if (charCode >= 48 && charCode <= 57) {
                  // Leading zeroes are interpreted as octal literals.
                  if (charCode == 48 && ((charCode = source.charCodeAt(Index + 1)), charCode >= 48 && charCode <= 57)) {
                    // Illegal octal literal.
                    abort();
                  }
                  isSigned = false;
                  // Parse the integer component.
                  for (; Index < length && ((charCode = source.charCodeAt(Index)), charCode >= 48 && charCode <= 57); Index++);
                  // Floats cannot contain a leading decimal point; however, this
                  // case is already accounted for by the parser.
                  if (source.charCodeAt(Index) == 46) {
                    position = ++Index;
                    // Parse the decimal component.
                    for (; position < length && ((charCode = source.charCodeAt(position)), charCode >= 48 && charCode <= 57); position++);
                    if (position == Index) {
                      // Illegal trailing decimal.
                      abort();
                    }
                    Index = position;
                  }
                  // Parse exponents. The `e` denoting the exponent is
                  // case-insensitive.
                  charCode = source.charCodeAt(Index);
                  if (charCode == 101 || charCode == 69) {
                    charCode = source.charCodeAt(++Index);
                    // Skip past the sign following the exponent, if one is
                    // specified.
                    if (charCode == 43 || charCode == 45) {
                      Index++;
                    }
                    // Parse the exponential component.
                    for (position = Index; position < length && ((charCode = source.charCodeAt(position)), charCode >= 48 && charCode <= 57); position++);
                    if (position == Index) {
                      // Illegal empty exponent.
                      abort();
                    }
                    Index = position;
                  }
                  // Coerce the parsed value to a JavaScript number.
                  return +source.slice(begin, Index);
                }
                // A negative sign may only precede numbers.
                if (isSigned) {
                  abort();
                }
                // `true`, `false`, and `null` literals.
                if (source.slice(Index, Index + 4) == "true") {
                  Index += 4;
                  return true;
                } else if (source.slice(Index, Index + 5) == "false") {
                  Index += 5;
                  return false;
                } else if (source.slice(Index, Index + 4) == "null") {
                  Index += 4;
                  return null;
                }
                // Unrecognized token.
                abort();
            }
          }
          // Return the sentinel `$` character if the parser has reached the end
          // of the source string.
          return "$";
        };

        // Internal: Parses a JSON `value` token.
        var get = function (value) {
          var results, hasMembers;
          if (value == "$") {
            // Unexpected end of input.
            abort();
          }
          if (typeof value == "string") {
            if ((charIndexBuggy ? value.charAt(0) : value[0]) == "@") {
              // Remove the sentinel `@` character.
              return value.slice(1);
            }
            // Parse object and array literals.
            if (value == "[") {
              // Parses a JSON array, returning a new JavaScript array.
              results = [];
              for (;; hasMembers || (hasMembers = true)) {
                value = lex();
                // A closing square bracket marks the end of the array literal.
                if (value == "]") {
                  break;
                }
                // If the array literal contains elements, the current token
                // should be a comma separating the previous element from the
                // next.
                if (hasMembers) {
                  if (value == ",") {
                    value = lex();
                    if (value == "]") {
                      // Unexpected trailing `,` in array literal.
                      abort();
                    }
                  } else {
                    // A `,` must separate each array element.
                    abort();
                  }
                }
                // Elisions and leading commas are not permitted.
                if (value == ",") {
                  abort();
                }
                results.push(get(value));
              }
              return results;
            } else if (value == "{") {
              // Parses a JSON object, returning a new JavaScript object.
              results = {};
              for (;; hasMembers || (hasMembers = true)) {
                value = lex();
                // A closing curly brace marks the end of the object literal.
                if (value == "}") {
                  break;
                }
                // If the object literal contains members, the current token
                // should be a comma separator.
                if (hasMembers) {
                  if (value == ",") {
                    value = lex();
                    if (value == "}") {
                      // Unexpected trailing `,` in object literal.
                      abort();
                    }
                  } else {
                    // A `,` must separate each object member.
                    abort();
                  }
                }
                // Leading commas are not permitted, object property names must be
                // double-quoted strings, and a `:` must separate each property
                // name and value.
                if (value == "," || typeof value != "string" || (charIndexBuggy ? value.charAt(0) : value[0]) != "@" || lex() != ":") {
                  abort();
                }
                results[value.slice(1)] = get(lex());
              }
              return results;
            }
            // Unexpected token encountered.
            abort();
          }
          return value;
        };

        // Internal: Updates a traversed object member.
        var update = function (source, property, callback) {
          var element = walk(source, property, callback);
          if (element === undef) {
            delete source[property];
          } else {
            source[property] = element;
          }
        };

        // Internal: Recursively traverses a parsed JSON object, invoking the
        // `callback` function for each value. This is an implementation of the
        // `Walk(holder, name)` operation defined in ES 5.1 section 15.12.2.
        var walk = function (source, property, callback) {
          var value = source[property], length;
          if (typeof value == "object" && value) {
            // `forEach` can't be used to traverse an array in Opera <= 8.54
            // because its `Object#hasOwnProperty` implementation returns `false`
            // for array indices (e.g., `![1, 2, 3].hasOwnProperty("0")`).
            if (getClass.call(value) == arrayClass) {
              for (length = value.length; length--;) {
                update(value, length, callback);
              }
            } else {
              forEach(value, function (property) {
                update(value, property, callback);
              });
            }
          }
          return callback.call(source, property, value);
        };

        // Public: `JSON.parse`. See ES 5.1 section 15.12.2.
        exports.parse = function (source, callback) {
          var result, value;
          Index = 0;
          Source = "" + source;
          result = get(lex());
          // If a JSON string contains multiple tokens, it is invalid.
          if (lex() != "$") {
            abort();
          }
          // Reset the parser state.
          Index = Source = null;
          return callback && getClass.call(callback) == functionClass ? walk((value = {}, value[""] = result, value), "", callback) : result;
        };
      }
    }

    exports["runInContext"] = runInContext;
    return exports;
  }

  if (typeof exports == "object" && exports && !exports.nodeType && !isLoader) {
    // Export for CommonJS environments.
    runInContext(root, exports);
  } else {
    // Export for web browsers and JavaScript engines.
    var nativeJSON = root.JSON;
    var JSON3 = runInContext(root, (root["JSON3"] = {
      // Public: Restores the original value of the global `JSON` object and
      // returns a reference to the `JSON3` object.
      "noConflict": function () {
        root.JSON = nativeJSON;
        return JSON3;
      }
    }));

    root.JSON = {
      "parse": JSON3.parse,
      "stringify": JSON3.stringify
    };
  }

  // Export for asynchronous module loaders.
  if (isLoader) {
    define(function () {
      return JSON3;
    });
  }
}(this));

//     Underscore.js 1.6.0
//     http://underscorejs.org
//     (c) 2009-2014 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
//     Underscore may be freely distributed under the MIT license.

(function() {

  // Baseline setup
  // --------------

  // Establish the root object, `window` in the browser, or `exports` on the server.
  var root = this;

  // Save the previous value of the `_` variable.
  var previousUnderscore = root._;

  // Establish the object that gets returned to break out of a loop iteration.
  var breaker = {};

  // Save bytes in the minified (but not gzipped) version:
  var ArrayProto = Array.prototype, ObjProto = Object.prototype, FuncProto = Function.prototype;

  // Create quick reference variables for speed access to core prototypes.
  var
    push             = ArrayProto.push,
    slice            = ArrayProto.slice,
    concat           = ArrayProto.concat,
    toString         = ObjProto.toString,
    hasOwnProperty   = ObjProto.hasOwnProperty;

  // All **ECMAScript 5** native function implementations that we hope to use
  // are declared here.
  var
    nativeForEach      = ArrayProto.forEach,
    nativeMap          = ArrayProto.map,
    nativeReduce       = ArrayProto.reduce,
    nativeReduceRight  = ArrayProto.reduceRight,
    nativeFilter       = ArrayProto.filter,
    nativeEvery        = ArrayProto.every,
    nativeSome         = ArrayProto.some,
    nativeIndexOf      = ArrayProto.indexOf,
    nativeLastIndexOf  = ArrayProto.lastIndexOf,
    nativeIsArray      = Array.isArray,
    nativeKeys         = Object.keys,
    nativeBind         = FuncProto.bind;

  // Create a safe reference to the Underscore object for use below.
  var _ = function(obj) {
    if (obj instanceof _) return obj;
    if (!(this instanceof _)) return new _(obj);
    this._wrapped = obj;
  };

  // Export the Underscore object for **Node.js**, with
  // backwards-compatibility for the old `require()` API. If we're in
  // the browser, add `_` as a global object via a string identifier,
  // for Closure Compiler "advanced" mode.
  if (typeof exports !== 'undefined') {
    if (typeof module !== 'undefined' && module.exports) {
      exports = module.exports = _;
    }
    exports._ = _;
  } else {
    root._ = _;
  }

  // Current version.
  _.VERSION = '1.6.0';

  // Collection Functions
  // --------------------

  // The cornerstone, an `each` implementation, aka `forEach`.
  // Handles objects with the built-in `forEach`, arrays, and raw objects.
  // Delegates to **ECMAScript 5**'s native `forEach` if available.
  var each = _.each = _.forEach = function(obj, iterator, context) {
    if (obj == null) return obj;
    if (nativeForEach && obj.forEach === nativeForEach) {
      obj.forEach(iterator, context);
    } else if (obj.length === +obj.length) {
      for (var i = 0, length = obj.length; i < length; i++) {
        if (iterator.call(context, obj[i], i, obj) === breaker) return;
      }
    } else {
      var keys = _.keys(obj);
      for (var i = 0, length = keys.length; i < length; i++) {
        if (iterator.call(context, obj[keys[i]], keys[i], obj) === breaker) return;
      }
    }
    return obj;
  };

  // Return the results of applying the iterator to each element.
  // Delegates to **ECMAScript 5**'s native `map` if available.
  _.map = _.collect = function(obj, iterator, context) {
    var results = [];
    if (obj == null) return results;
    if (nativeMap && obj.map === nativeMap) return obj.map(iterator, context);
    each(obj, function(value, index, list) {
      results.push(iterator.call(context, value, index, list));
    });
    return results;
  };

  var reduceError = 'Reduce of empty array with no initial value';

  // **Reduce** builds up a single result from a list of values, aka `inject`,
  // or `foldl`. Delegates to **ECMAScript 5**'s native `reduce` if available.
  _.reduce = _.foldl = _.inject = function(obj, iterator, memo, context) {
    var initial = arguments.length > 2;
    if (obj == null) obj = [];
    if (nativeReduce && obj.reduce === nativeReduce) {
      if (context) iterator = _.bind(iterator, context);
      return initial ? obj.reduce(iterator, memo) : obj.reduce(iterator);
    }
    each(obj, function(value, index, list) {
      if (!initial) {
        memo = value;
        initial = true;
      } else {
        memo = iterator.call(context, memo, value, index, list);
      }
    });
    if (!initial) throw new TypeError(reduceError);
    return memo;
  };

  // The right-associative version of reduce, also known as `foldr`.
  // Delegates to **ECMAScript 5**'s native `reduceRight` if available.
  _.reduceRight = _.foldr = function(obj, iterator, memo, context) {
    var initial = arguments.length > 2;
    if (obj == null) obj = [];
    if (nativeReduceRight && obj.reduceRight === nativeReduceRight) {
      if (context) iterator = _.bind(iterator, context);
      return initial ? obj.reduceRight(iterator, memo) : obj.reduceRight(iterator);
    }
    var length = obj.length;
    if (length !== +length) {
      var keys = _.keys(obj);
      length = keys.length;
    }
    each(obj, function(value, index, list) {
      index = keys ? keys[--length] : --length;
      if (!initial) {
        memo = obj[index];
        initial = true;
      } else {
        memo = iterator.call(context, memo, obj[index], index, list);
      }
    });
    if (!initial) throw new TypeError(reduceError);
    return memo;
  };

  // Return the first value which passes a truth test. Aliased as `detect`.
  _.find = _.detect = function(obj, predicate, context) {
    var result;
    any(obj, function(value, index, list) {
      if (predicate.call(context, value, index, list)) {
        result = value;
        return true;
      }
    });
    return result;
  };

  // Return all the elements that pass a truth test.
  // Delegates to **ECMAScript 5**'s native `filter` if available.
  // Aliased as `select`.
  _.filter = _.select = function(obj, predicate, context) {
    var results = [];
    if (obj == null) return results;
    if (nativeFilter && obj.filter === nativeFilter) return obj.filter(predicate, context);
    each(obj, function(value, index, list) {
      if (predicate.call(context, value, index, list)) results.push(value);
    });
    return results;
  };

  // Return all the elements for which a truth test fails.
  _.reject = function(obj, predicate, context) {
    return _.filter(obj, function(value, index, list) {
      return !predicate.call(context, value, index, list);
    }, context);
  };

  // Determine whether all of the elements match a truth test.
  // Delegates to **ECMAScript 5**'s native `every` if available.
  // Aliased as `all`.
  _.every = _.all = function(obj, predicate, context) {
    predicate || (predicate = _.identity);
    var result = true;
    if (obj == null) return result;
    if (nativeEvery && obj.every === nativeEvery) return obj.every(predicate, context);
    each(obj, function(value, index, list) {
      if (!(result = result && predicate.call(context, value, index, list))) return breaker;
    });
    return !!result;
  };

  // Determine if at least one element in the object matches a truth test.
  // Delegates to **ECMAScript 5**'s native `some` if available.
  // Aliased as `any`.
  var any = _.some = _.any = function(obj, predicate, context) {
    predicate || (predicate = _.identity);
    var result = false;
    if (obj == null) return result;
    if (nativeSome && obj.some === nativeSome) return obj.some(predicate, context);
    each(obj, function(value, index, list) {
      if (result || (result = predicate.call(context, value, index, list))) return breaker;
    });
    return !!result;
  };

  // Determine if the array or object contains a given value (using `===`).
  // Aliased as `include`.
  _.contains = _.include = function(obj, target) {
    if (obj == null) return false;
    if (nativeIndexOf && obj.indexOf === nativeIndexOf) return obj.indexOf(target) != -1;
    return any(obj, function(value) {
      return value === target;
    });
  };

  // Invoke a method (with arguments) on every item in a collection.
  _.invoke = function(obj, method) {
    var args = slice.call(arguments, 2);
    var isFunc = _.isFunction(method);
    return _.map(obj, function(value) {
      return (isFunc ? method : value[method]).apply(value, args);
    });
  };

  // Convenience version of a common use case of `map`: fetching a property.
  _.pluck = function(obj, key) {
    return _.map(obj, _.property(key));
  };

  // Convenience version of a common use case of `filter`: selecting only objects
  // containing specific `key:value` pairs.
  _.where = function(obj, attrs) {
    return _.filter(obj, _.matches(attrs));
  };

  // Convenience version of a common use case of `find`: getting the first object
  // containing specific `key:value` pairs.
  _.findWhere = function(obj, attrs) {
    return _.find(obj, _.matches(attrs));
  };

  // Return the maximum element or (element-based computation).
  // Can't optimize arrays of integers longer than 65,535 elements.
  // See [WebKit Bug 80797](https://bugs.webkit.org/show_bug.cgi?id=80797)
  _.max = function(obj, iterator, context) {
    if (!iterator && _.isArray(obj) && obj[0] === +obj[0] && obj.length < 65535) {
      return Math.max.apply(Math, obj);
    }
    var result = -Infinity, lastComputed = -Infinity;
    each(obj, function(value, index, list) {
      var computed = iterator ? iterator.call(context, value, index, list) : value;
      if (computed > lastComputed) {
        result = value;
        lastComputed = computed;
      }
    });
    return result;
  };

  // Return the minimum element (or element-based computation).
  _.min = function(obj, iterator, context) {
    if (!iterator && _.isArray(obj) && obj[0] === +obj[0] && obj.length < 65535) {
      return Math.min.apply(Math, obj);
    }
    var result = Infinity, lastComputed = Infinity;
    each(obj, function(value, index, list) {
      var computed = iterator ? iterator.call(context, value, index, list) : value;
      if (computed < lastComputed) {
        result = value;
        lastComputed = computed;
      }
    });
    return result;
  };

  // Shuffle an array, using the modern version of the
  // [Fisher-Yates shuffle](http://en.wikipedia.org/wiki/Fisher–Yates_shuffle).
  _.shuffle = function(obj) {
    var rand;
    var index = 0;
    var shuffled = [];
    each(obj, function(value) {
      rand = _.random(index++);
      shuffled[index - 1] = shuffled[rand];
      shuffled[rand] = value;
    });
    return shuffled;
  };

  // Sample **n** random values from a collection.
  // If **n** is not specified, returns a single random element.
  // The internal `guard` argument allows it to work with `map`.
  _.sample = function(obj, n, guard) {
    if (n == null || guard) {
      if (obj.length !== +obj.length) obj = _.values(obj);
      return obj[_.random(obj.length - 1)];
    }
    return _.shuffle(obj).slice(0, Math.max(0, n));
  };

  // An internal function to generate lookup iterators.
  var lookupIterator = function(value) {
    if (value == null) return _.identity;
    if (_.isFunction(value)) return value;
    return _.property(value);
  };

  // Sort the object's values by a criterion produced by an iterator.
  _.sortBy = function(obj, iterator, context) {
    iterator = lookupIterator(iterator);
    return _.pluck(_.map(obj, function(value, index, list) {
      return {
        value: value,
        index: index,
        criteria: iterator.call(context, value, index, list)
      };
    }).sort(function(left, right) {
      var a = left.criteria;
      var b = right.criteria;
      if (a !== b) {
        if (a > b || a === void 0) return 1;
        if (a < b || b === void 0) return -1;
      }
      return left.index - right.index;
    }), 'value');
  };

  // An internal function used for aggregate "group by" operations.
  var group = function(behavior) {
    return function(obj, iterator, context) {
      var result = {};
      iterator = lookupIterator(iterator);
      each(obj, function(value, index) {
        var key = iterator.call(context, value, index, obj);
        behavior(result, key, value);
      });
      return result;
    };
  };

  // Groups the object's values by a criterion. Pass either a string attribute
  // to group by, or a function that returns the criterion.
  _.groupBy = group(function(result, key, value) {
    _.has(result, key) ? result[key].push(value) : result[key] = [value];
  });

  // Indexes the object's values by a criterion, similar to `groupBy`, but for
  // when you know that your index values will be unique.
  _.indexBy = group(function(result, key, value) {
    result[key] = value;
  });

  // Counts instances of an object that group by a certain criterion. Pass
  // either a string attribute to count by, or a function that returns the
  // criterion.
  _.countBy = group(function(result, key) {
    _.has(result, key) ? result[key]++ : result[key] = 1;
  });

  // Use a comparator function to figure out the smallest index at which
  // an object should be inserted so as to maintain order. Uses binary search.
  _.sortedIndex = function(array, obj, iterator, context) {
    iterator = lookupIterator(iterator);
    var value = iterator.call(context, obj);
    var low = 0, high = array.length;
    while (low < high) {
      var mid = (low + high) >>> 1;
      iterator.call(context, array[mid]) < value ? low = mid + 1 : high = mid;
    }
    return low;
  };

  // Safely create a real, live array from anything iterable.
  _.toArray = function(obj) {
    if (!obj) return [];
    if (_.isArray(obj)) return slice.call(obj);
    if (obj.length === +obj.length) return _.map(obj, _.identity);
    return _.values(obj);
  };

  // Return the number of elements in an object.
  _.size = function(obj) {
    if (obj == null) return 0;
    return (obj.length === +obj.length) ? obj.length : _.keys(obj).length;
  };

  // Array Functions
  // ---------------

  // Get the first element of an array. Passing **n** will return the first N
  // values in the array. Aliased as `head` and `take`. The **guard** check
  // allows it to work with `_.map`.
  _.first = _.head = _.take = function(array, n, guard) {
    if (array == null) return void 0;
    if ((n == null) || guard) return array[0];
    if (n < 0) return [];
    return slice.call(array, 0, n);
  };

  // Returns everything but the last entry of the array. Especially useful on
  // the arguments object. Passing **n** will return all the values in
  // the array, excluding the last N. The **guard** check allows it to work with
  // `_.map`.
  _.initial = function(array, n, guard) {
    return slice.call(array, 0, array.length - ((n == null) || guard ? 1 : n));
  };

  // Get the last element of an array. Passing **n** will return the last N
  // values in the array. The **guard** check allows it to work with `_.map`.
  _.last = function(array, n, guard) {
    if (array == null) return void 0;
    if ((n == null) || guard) return array[array.length - 1];
    return slice.call(array, Math.max(array.length - n, 0));
  };

  // Returns everything but the first entry of the array. Aliased as `tail` and `drop`.
  // Especially useful on the arguments object. Passing an **n** will return
  // the rest N values in the array. The **guard**
  // check allows it to work with `_.map`.
  _.rest = _.tail = _.drop = function(array, n, guard) {
    return slice.call(array, (n == null) || guard ? 1 : n);
  };

  // Trim out all falsy values from an array.
  _.compact = function(array) {
    return _.filter(array, _.identity);
  };

  // Internal implementation of a recursive `flatten` function.
  var flatten = function(input, shallow, output) {
    if (shallow && _.every(input, _.isArray)) {
      return concat.apply(output, input);
    }
    each(input, function(value) {
      if (_.isArray(value) || _.isArguments(value)) {
        shallow ? push.apply(output, value) : flatten(value, shallow, output);
      } else {
        output.push(value);
      }
    });
    return output;
  };

  // Flatten out an array, either recursively (by default), or just one level.
  _.flatten = function(array, shallow) {
    return flatten(array, shallow, []);
  };

  // Return a version of the array that does not contain the specified value(s).
  _.without = function(array) {
    return _.difference(array, slice.call(arguments, 1));
  };

  // Split an array into two arrays: one whose elements all satisfy the given
  // predicate, and one whose elements all do not satisfy the predicate.
  _.partition = function(array, predicate) {
    var pass = [], fail = [];
    each(array, function(elem) {
      (predicate(elem) ? pass : fail).push(elem);
    });
    return [pass, fail];
  };

  // Produce a duplicate-free version of the array. If the array has already
  // been sorted, you have the option of using a faster algorithm.
  // Aliased as `unique`.
  _.uniq = _.unique = function(array, isSorted, iterator, context) {
    if (_.isFunction(isSorted)) {
      context = iterator;
      iterator = isSorted;
      isSorted = false;
    }
    var initial = iterator ? _.map(array, iterator, context) : array;
    var results = [];
    var seen = [];
    each(initial, function(value, index) {
      if (isSorted ? (!index || seen[seen.length - 1] !== value) : !_.contains(seen, value)) {
        seen.push(value);
        results.push(array[index]);
      }
    });
    return results;
  };

  // Produce an array that contains the union: each distinct element from all of
  // the passed-in arrays.
  _.union = function() {
    return _.uniq(_.flatten(arguments, true));
  };

  // Produce an array that contains every item shared between all the
  // passed-in arrays.
  _.intersection = function(array) {
    var rest = slice.call(arguments, 1);
    return _.filter(_.uniq(array), function(item) {
      return _.every(rest, function(other) {
        return _.contains(other, item);
      });
    });
  };

  // Take the difference between one array and a number of other arrays.
  // Only the elements present in just the first array will remain.
  _.difference = function(array) {
    var rest = concat.apply(ArrayProto, slice.call(arguments, 1));
    return _.filter(array, function(value){ return !_.contains(rest, value); });
  };

  // Zip together multiple lists into a single array -- elements that share
  // an index go together.
  _.zip = function() {
    var length = _.max(_.pluck(arguments, 'length').concat(0));
    var results = new Array(length);
    for (var i = 0; i < length; i++) {
      results[i] = _.pluck(arguments, '' + i);
    }
    return results;
  };

  // Converts lists into objects. Pass either a single array of `[key, value]`
  // pairs, or two parallel arrays of the same length -- one of keys, and one of
  // the corresponding values.
  _.object = function(list, values) {
    if (list == null) return {};
    var result = {};
    for (var i = 0, length = list.length; i < length; i++) {
      if (values) {
        result[list[i]] = values[i];
      } else {
        result[list[i][0]] = list[i][1];
      }
    }
    return result;
  };

  // If the browser doesn't supply us with indexOf (I'm looking at you, **MSIE**),
  // we need this function. Return the position of the first occurrence of an
  // item in an array, or -1 if the item is not included in the array.
  // Delegates to **ECMAScript 5**'s native `indexOf` if available.
  // If the array is large and already in sort order, pass `true`
  // for **isSorted** to use binary search.
  _.indexOf = function(array, item, isSorted) {
    if (array == null) return -1;
    var i = 0, length = array.length;
    if (isSorted) {
      if (typeof isSorted == 'number') {
        i = (isSorted < 0 ? Math.max(0, length + isSorted) : isSorted);
      } else {
        i = _.sortedIndex(array, item);
        return array[i] === item ? i : -1;
      }
    }
    if (nativeIndexOf && array.indexOf === nativeIndexOf) return array.indexOf(item, isSorted);
    for (; i < length; i++) if (array[i] === item) return i;
    return -1;
  };

  // Delegates to **ECMAScript 5**'s native `lastIndexOf` if available.
  _.lastIndexOf = function(array, item, from) {
    if (array == null) return -1;
    var hasIndex = from != null;
    if (nativeLastIndexOf && array.lastIndexOf === nativeLastIndexOf) {
      return hasIndex ? array.lastIndexOf(item, from) : array.lastIndexOf(item);
    }
    var i = (hasIndex ? from : array.length);
    while (i--) if (array[i] === item) return i;
    return -1;
  };

  // Generate an integer Array containing an arithmetic progression. A port of
  // the native Python `range()` function. See
  // [the Python documentation](http://docs.python.org/library/functions.html#range).
  _.range = function(start, stop, step) {
    if (arguments.length <= 1) {
      stop = start || 0;
      start = 0;
    }
    step = arguments[2] || 1;

    var length = Math.max(Math.ceil((stop - start) / step), 0);
    var idx = 0;
    var range = new Array(length);

    while(idx < length) {
      range[idx++] = start;
      start += step;
    }

    return range;
  };

  // Function (ahem) Functions
  // ------------------

  // Reusable constructor function for prototype setting.
  var ctor = function(){};

  // Create a function bound to a given object (assigning `this`, and arguments,
  // optionally). Delegates to **ECMAScript 5**'s native `Function.bind` if
  // available.
  _.bind = function(func, context) {
    var args, bound;
    if (nativeBind && func.bind === nativeBind) return nativeBind.apply(func, slice.call(arguments, 1));
    if (!_.isFunction(func)) throw new TypeError;
    args = slice.call(arguments, 2);
    return bound = function() {
      if (!(this instanceof bound)) return func.apply(context, args.concat(slice.call(arguments)));
      ctor.prototype = func.prototype;
      var self = new ctor;
      ctor.prototype = null;
      var result = func.apply(self, args.concat(slice.call(arguments)));
      if (Object(result) === result) return result;
      return self;
    };
  };

  // Partially apply a function by creating a version that has had some of its
  // arguments pre-filled, without changing its dynamic `this` context. _ acts
  // as a placeholder, allowing any combination of arguments to be pre-filled.
  _.partial = function(func) {
    var boundArgs = slice.call(arguments, 1);
    return function() {
      var position = 0;
      var args = boundArgs.slice();
      for (var i = 0, length = args.length; i < length; i++) {
        if (args[i] === _) args[i] = arguments[position++];
      }
      while (position < arguments.length) args.push(arguments[position++]);
      return func.apply(this, args);
    };
  };

  // Bind a number of an object's methods to that object. Remaining arguments
  // are the method names to be bound. Useful for ensuring that all callbacks
  // defined on an object belong to it.
  _.bindAll = function(obj) {
    var funcs = slice.call(arguments, 1);
    if (funcs.length === 0) throw new Error('bindAll must be passed function names');
    each(funcs, function(f) { obj[f] = _.bind(obj[f], obj); });
    return obj;
  };

  // Memoize an expensive function by storing its results.
  _.memoize = function(func, hasher) {
    var memo = {};
    hasher || (hasher = _.identity);
    return function() {
      var key = hasher.apply(this, arguments);
      return _.has(memo, key) ? memo[key] : (memo[key] = func.apply(this, arguments));
    };
  };

  // Delays a function for the given number of milliseconds, and then calls
  // it with the arguments supplied.
  _.delay = function(func, wait) {
    var args = slice.call(arguments, 2);
    return setTimeout(function(){ return func.apply(null, args); }, wait);
  };

  // Defers a function, scheduling it to run after the current call stack has
  // cleared.
  _.defer = function(func) {
    return _.delay.apply(_, [func, 1].concat(slice.call(arguments, 1)));
  };

  // Returns a function, that, when invoked, will only be triggered at most once
  // during a given window of time. Normally, the throttled function will run
  // as much as it can, without ever going more than once per `wait` duration;
  // but if you'd like to disable the execution on the leading edge, pass
  // `{leading: false}`. To disable execution on the trailing edge, ditto.
  _.throttle = function(func, wait, options) {
    var context, args, result;
    var timeout = null;
    var previous = 0;
    options || (options = {});
    var later = function() {
      previous = options.leading === false ? 0 : _.now();
      timeout = null;
      result = func.apply(context, args);
      context = args = null;
    };
    return function() {
      var now = _.now();
      if (!previous && options.leading === false) previous = now;
      var remaining = wait - (now - previous);
      context = this;
      args = arguments;
      if (remaining <= 0) {
        clearTimeout(timeout);
        timeout = null;
        previous = now;
        result = func.apply(context, args);
        context = args = null;
      } else if (!timeout && options.trailing !== false) {
        timeout = setTimeout(later, remaining);
      }
      return result;
    };
  };

  // Returns a function, that, as long as it continues to be invoked, will not
  // be triggered. The function will be called after it stops being called for
  // N milliseconds. If `immediate` is passed, trigger the function on the
  // leading edge, instead of the trailing.
  _.debounce = function(func, wait, immediate) {
    var timeout, args, context, timestamp, result;

    var later = function() {
      var last = _.now() - timestamp;
      if (last < wait) {
        timeout = setTimeout(later, wait - last);
      } else {
        timeout = null;
        if (!immediate) {
          result = func.apply(context, args);
          context = args = null;
        }
      }
    };

    return function() {
      context = this;
      args = arguments;
      timestamp = _.now();
      var callNow = immediate && !timeout;
      if (!timeout) {
        timeout = setTimeout(later, wait);
      }
      if (callNow) {
        result = func.apply(context, args);
        context = args = null;
      }

      return result;
    };
  };

  // Returns a function that will be executed at most one time, no matter how
  // often you call it. Useful for lazy initialization.
  _.once = function(func) {
    var ran = false, memo;
    return function() {
      if (ran) return memo;
      ran = true;
      memo = func.apply(this, arguments);
      func = null;
      return memo;
    };
  };

  // Returns the first function passed as an argument to the second,
  // allowing you to adjust arguments, run code before and after, and
  // conditionally execute the original function.
  _.wrap = function(func, wrapper) {
    return _.partial(wrapper, func);
  };

  // Returns a function that is the composition of a list of functions, each
  // consuming the return value of the function that follows.
  _.compose = function() {
    var funcs = arguments;
    return function() {
      var args = arguments;
      for (var i = funcs.length - 1; i >= 0; i--) {
        args = [funcs[i].apply(this, args)];
      }
      return args[0];
    };
  };

  // Returns a function that will only be executed after being called N times.
  _.after = function(times, func) {
    return function() {
      if (--times < 1) {
        return func.apply(this, arguments);
      }
    };
  };

  // Object Functions
  // ----------------

  // Retrieve the names of an object's properties.
  // Delegates to **ECMAScript 5**'s native `Object.keys`
  _.keys = function(obj) {
    if (!_.isObject(obj)) return [];
    if (nativeKeys) return nativeKeys(obj);
    var keys = [];
    for (var key in obj) if (_.has(obj, key)) keys.push(key);
    return keys;
  };

  // Retrieve the values of an object's properties.
  _.values = function(obj) {
    var keys = _.keys(obj);
    var length = keys.length;
    var values = new Array(length);
    for (var i = 0; i < length; i++) {
      values[i] = obj[keys[i]];
    }
    return values;
  };

  // Convert an object into a list of `[key, value]` pairs.
  _.pairs = function(obj) {
    var keys = _.keys(obj);
    var length = keys.length;
    var pairs = new Array(length);
    for (var i = 0; i < length; i++) {
      pairs[i] = [keys[i], obj[keys[i]]];
    }
    return pairs;
  };

  // Invert the keys and values of an object. The values must be serializable.
  _.invert = function(obj) {
    var result = {};
    var keys = _.keys(obj);
    for (var i = 0, length = keys.length; i < length; i++) {
      result[obj[keys[i]]] = keys[i];
    }
    return result;
  };

  // Return a sorted list of the function names available on the object.
  // Aliased as `methods`
  _.functions = _.methods = function(obj) {
    var names = [];
    for (var key in obj) {
      if (_.isFunction(obj[key])) names.push(key);
    }
    return names.sort();
  };

  // Extend a given object with all the properties in passed-in object(s).
  _.extend = function(obj) {
    each(slice.call(arguments, 1), function(source) {
      if (source) {
        for (var prop in source) {
          obj[prop] = source[prop];
        }
      }
    });
    return obj;
  };

  // Return a copy of the object only containing the whitelisted properties.
  _.pick = function(obj) {
    var copy = {};
    var keys = concat.apply(ArrayProto, slice.call(arguments, 1));
    each(keys, function(key) {
      if (key in obj) copy[key] = obj[key];
    });
    return copy;
  };

   // Return a copy of the object without the blacklisted properties.
  _.omit = function(obj) {
    var copy = {};
    var keys = concat.apply(ArrayProto, slice.call(arguments, 1));
    for (var key in obj) {
      if (!_.contains(keys, key)) copy[key] = obj[key];
    }
    return copy;
  };

  // Fill in a given object with default properties.
  _.defaults = function(obj) {
    each(slice.call(arguments, 1), function(source) {
      if (source) {
        for (var prop in source) {
          if (obj[prop] === void 0) obj[prop] = source[prop];
        }
      }
    });
    return obj;
  };

  // Create a (shallow-cloned) duplicate of an object.
  _.clone = function(obj) {
    if (!_.isObject(obj)) return obj;
    return _.isArray(obj) ? obj.slice() : _.extend({}, obj);
  };

  // Invokes interceptor with the obj, and then returns obj.
  // The primary purpose of this method is to "tap into" a method chain, in
  // order to perform operations on intermediate results within the chain.
  _.tap = function(obj, interceptor) {
    interceptor(obj);
    return obj;
  };

  // Internal recursive comparison function for `isEqual`.
  var eq = function(a, b, aStack, bStack) {
    // Identical objects are equal. `0 === -0`, but they aren't identical.
    // See the [Harmony `egal` proposal](http://wiki.ecmascript.org/doku.php?id=harmony:egal).
    if (a === b) return a !== 0 || 1 / a == 1 / b;
    // A strict comparison is necessary because `null == undefined`.
    if (a == null || b == null) return a === b;
    // Unwrap any wrapped objects.
    if (a instanceof _) a = a._wrapped;
    if (b instanceof _) b = b._wrapped;
    // Compare `[[Class]]` names.
    var className = toString.call(a);
    if (className != toString.call(b)) return false;
    switch (className) {
      // Strings, numbers, dates, and booleans are compared by value.
      case '[object String]':
        // Primitives and their corresponding object wrappers are equivalent; thus, `"5"` is
        // equivalent to `new String("5")`.
        return a == String(b);
      case '[object Number]':
        // `NaN`s are equivalent, but non-reflexive. An `egal` comparison is performed for
        // other numeric values.
        return a != +a ? b != +b : (a == 0 ? 1 / a == 1 / b : a == +b);
      case '[object Date]':
      case '[object Boolean]':
        // Coerce dates and booleans to numeric primitive values. Dates are compared by their
        // millisecond representations. Note that invalid dates with millisecond representations
        // of `NaN` are not equivalent.
        return +a == +b;
      // RegExps are compared by their source patterns and flags.
      case '[object RegExp]':
        return a.source == b.source &&
               a.global == b.global &&
               a.multiline == b.multiline &&
               a.ignoreCase == b.ignoreCase;
    }
    if (typeof a != 'object' || typeof b != 'object') return false;
    // Assume equality for cyclic structures. The algorithm for detecting cyclic
    // structures is adapted from ES 5.1 section 15.12.3, abstract operation `JO`.
    var length = aStack.length;
    while (length--) {
      // Linear search. Performance is inversely proportional to the number of
      // unique nested structures.
      if (aStack[length] == a) return bStack[length] == b;
    }
    // Objects with different constructors are not equivalent, but `Object`s
    // from different frames are.
    var aCtor = a.constructor, bCtor = b.constructor;
    if (aCtor !== bCtor && !(_.isFunction(aCtor) && (aCtor instanceof aCtor) &&
                             _.isFunction(bCtor) && (bCtor instanceof bCtor))
                        && ('constructor' in a && 'constructor' in b)) {
      return false;
    }
    // Add the first object to the stack of traversed objects.
    aStack.push(a);
    bStack.push(b);
    var size = 0, result = true;
    // Recursively compare objects and arrays.
    if (className == '[object Array]') {
      // Compare array lengths to determine if a deep comparison is necessary.
      size = a.length;
      result = size == b.length;
      if (result) {
        // Deep compare the contents, ignoring non-numeric properties.
        while (size--) {
          if (!(result = eq(a[size], b[size], aStack, bStack))) break;
        }
      }
    } else {
      // Deep compare objects.
      for (var key in a) {
        if (_.has(a, key)) {
          // Count the expected number of properties.
          size++;
          // Deep compare each member.
          if (!(result = _.has(b, key) && eq(a[key], b[key], aStack, bStack))) break;
        }
      }
      // Ensure that both objects contain the same number of properties.
      if (result) {
        for (key in b) {
          if (_.has(b, key) && !(size--)) break;
        }
        result = !size;
      }
    }
    // Remove the first object from the stack of traversed objects.
    aStack.pop();
    bStack.pop();
    return result;
  };

  // Perform a deep comparison to check if two objects are equal.
  _.isEqual = function(a, b) {
    return eq(a, b, [], []);
  };

  // Is a given array, string, or object empty?
  // An "empty" object has no enumerable own-properties.
  _.isEmpty = function(obj) {
    if (obj == null) return true;
    if (_.isArray(obj) || _.isString(obj)) return obj.length === 0;
    for (var key in obj) if (_.has(obj, key)) return false;
    return true;
  };

  // Is a given value a DOM element?
  _.isElement = function(obj) {
    return !!(obj && obj.nodeType === 1);
  };

  // Is a given value an array?
  // Delegates to ECMA5's native Array.isArray
  _.isArray = nativeIsArray || function(obj) {
    return toString.call(obj) == '[object Array]';
  };

  // Is a given variable an object?
  _.isObject = function(obj) {
    return obj === Object(obj);
  };

  // Add some isType methods: isArguments, isFunction, isString, isNumber, isDate, isRegExp.
  each(['Arguments', 'Function', 'String', 'Number', 'Date', 'RegExp'], function(name) {
    _['is' + name] = function(obj) {
      return toString.call(obj) == '[object ' + name + ']';
    };
  });

  // Define a fallback version of the method in browsers (ahem, IE), where
  // there isn't any inspectable "Arguments" type.
  if (!_.isArguments(arguments)) {
    _.isArguments = function(obj) {
      return !!(obj && _.has(obj, 'callee'));
    };
  }

  // Optimize `isFunction` if appropriate.
  if (typeof (/./) !== 'function') {
    _.isFunction = function(obj) {
      return typeof obj === 'function';
    };
  }

  // Is a given object a finite number?
  _.isFinite = function(obj) {
    return isFinite(obj) && !isNaN(parseFloat(obj));
  };

  // Is the given value `NaN`? (NaN is the only number which does not equal itself).
  _.isNaN = function(obj) {
    return _.isNumber(obj) && obj != +obj;
  };

  // Is a given value a boolean?
  _.isBoolean = function(obj) {
    return obj === true || obj === false || toString.call(obj) == '[object Boolean]';
  };

  // Is a given value equal to null?
  _.isNull = function(obj) {
    return obj === null;
  };

  // Is a given variable undefined?
  _.isUndefined = function(obj) {
    return obj === void 0;
  };

  // Shortcut function for checking if an object has a given property directly
  // on itself (in other words, not on a prototype).
  _.has = function(obj, key) {
    return hasOwnProperty.call(obj, key);
  };

  // Utility Functions
  // -----------------

  // Run Underscore.js in *noConflict* mode, returning the `_` variable to its
  // previous owner. Returns a reference to the Underscore object.
  _.noConflict = function() {
    root._ = previousUnderscore;
    return this;
  };

  // Keep the identity function around for default iterators.
  _.identity = function(value) {
    return value;
  };

  _.constant = function(value) {
    return function () {
      return value;
    };
  };

  _.property = function(key) {
    return function(obj) {
      return obj[key];
    };
  };

  // Returns a predicate for checking whether an object has a given set of `key:value` pairs.
  _.matches = function(attrs) {
    return function(obj) {
      if (obj === attrs) return true; //avoid comparing an object to itself.
      for (var key in attrs) {
        if (attrs[key] !== obj[key])
          return false;
      }
      return true;
    }
  };

  // Run a function **n** times.
  _.times = function(n, iterator, context) {
    var accum = Array(Math.max(0, n));
    for (var i = 0; i < n; i++) accum[i] = iterator.call(context, i);
    return accum;
  };

  // Return a random integer between min and max (inclusive).
  _.random = function(min, max) {
    if (max == null) {
      max = min;
      min = 0;
    }
    return min + Math.floor(Math.random() * (max - min + 1));
  };

  // A (possibly faster) way to get the current timestamp as an integer.
  _.now = Date.now || function() { return new Date().getTime(); };

  // List of HTML entities for escaping.
  var entityMap = {
    escape: {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#x27;'
    }
  };
  entityMap.unescape = _.invert(entityMap.escape);

  // Regexes containing the keys and values listed immediately above.
  var entityRegexes = {
    escape:   new RegExp('[' + _.keys(entityMap.escape).join('') + ']', 'g'),
    unescape: new RegExp('(' + _.keys(entityMap.unescape).join('|') + ')', 'g')
  };

  // Functions for escaping and unescaping strings to/from HTML interpolation.
  _.each(['escape', 'unescape'], function(method) {
    _[method] = function(string) {
      if (string == null) return '';
      return ('' + string).replace(entityRegexes[method], function(match) {
        return entityMap[method][match];
      });
    };
  });

  // If the value of the named `property` is a function then invoke it with the
  // `object` as context; otherwise, return it.
  _.result = function(object, property) {
    if (object == null) return void 0;
    var value = object[property];
    return _.isFunction(value) ? value.call(object) : value;
  };

  // Add your own custom functions to the Underscore object.
  _.mixin = function(obj) {
    each(_.functions(obj), function(name) {
      var func = _[name] = obj[name];
      _.prototype[name] = function() {
        var args = [this._wrapped];
        push.apply(args, arguments);
        return result.call(this, func.apply(_, args));
      };
    });
  };

  // Generate a unique integer id (unique within the entire client session).
  // Useful for temporary DOM ids.
  var idCounter = 0;
  _.uniqueId = function(prefix) {
    var id = ++idCounter + '';
    return prefix ? prefix + id : id;
  };

  // By default, Underscore uses ERB-style template delimiters, change the
  // following template settings to use alternative delimiters.
  _.templateSettings = {
    evaluate    : /<%([\s\S]+?)%>/g,
    interpolate : /<%=([\s\S]+?)%>/g,
    escape      : /<%-([\s\S]+?)%>/g
  };

  // When customizing `templateSettings`, if you don't want to define an
  // interpolation, evaluation or escaping regex, we need one that is
  // guaranteed not to match.
  var noMatch = /(.)^/;

  // Certain characters need to be escaped so that they can be put into a
  // string literal.
  var escapes = {
    "'":      "'",
    '\\':     '\\',
    '\r':     'r',
    '\n':     'n',
    '\t':     't',
    '\u2028': 'u2028',
    '\u2029': 'u2029'
  };

  var escaper = /\\|'|\r|\n|\t|\u2028|\u2029/g;

  // JavaScript micro-templating, similar to John Resig's implementation.
  // Underscore templating handles arbitrary delimiters, preserves whitespace,
  // and correctly escapes quotes within interpolated code.
  _.template = function(text, data, settings) {
    var render;
    settings = _.defaults({}, settings, _.templateSettings);

    // Combine delimiters into one regular expression via alternation.
    var matcher = new RegExp([
      (settings.escape || noMatch).source,
      (settings.interpolate || noMatch).source,
      (settings.evaluate || noMatch).source
    ].join('|') + '|$', 'g');

    // Compile the template source, escaping string literals appropriately.
    var index = 0;
    var source = "__p+='";
    text.replace(matcher, function(match, escape, interpolate, evaluate, offset) {
      source += text.slice(index, offset)
        .replace(escaper, function(match) { return '\\' + escapes[match]; });

      if (escape) {
        source += "'+\n((__t=(" + escape + "))==null?'':_.escape(__t))+\n'";
      }
      if (interpolate) {
        source += "'+\n((__t=(" + interpolate + "))==null?'':__t)+\n'";
      }
      if (evaluate) {
        source += "';\n" + evaluate + "\n__p+='";
      }
      index = offset + match.length;
      return match;
    });
    source += "';\n";

    // If a variable is not specified, place data values in local scope.
    if (!settings.variable) source = 'with(obj||{}){\n' + source + '}\n';

    source = "var __t,__p='',__j=Array.prototype.join," +
      "print=function(){__p+=__j.call(arguments,'');};\n" +
      source + "return __p;\n";

    try {
      render = new Function(settings.variable || 'obj', '_', source);
    } catch (e) {
      e.source = source;
      throw e;
    }

    if (data) return render(data, _);
    var template = function(data) {
      return render.call(this, data, _);
    };

    // Provide the compiled function source as a convenience for precompilation.
    template.source = 'function(' + (settings.variable || 'obj') + '){\n' + source + '}';

    return template;
  };

  // Add a "chain" function, which will delegate to the wrapper.
  _.chain = function(obj) {
    return _(obj).chain();
  };

  // OOP
  // ---------------
  // If Underscore is called as a function, it returns a wrapped object that
  // can be used OO-style. This wrapper holds altered versions of all the
  // underscore functions. Wrapped objects may be chained.

  // Helper function to continue chaining intermediate results.
  var result = function(obj) {
    return this._chain ? _(obj).chain() : obj;
  };

  // Add all of the Underscore functions to the wrapper object.
  _.mixin(_);

  // Add all mutator Array functions to the wrapper.
  each(['pop', 'push', 'reverse', 'shift', 'sort', 'splice', 'unshift'], function(name) {
    var method = ArrayProto[name];
    _.prototype[name] = function() {
      var obj = this._wrapped;
      method.apply(obj, arguments);
      if ((name == 'shift' || name == 'splice') && obj.length === 0) delete obj[0];
      return result.call(this, obj);
    };
  });

  // Add all accessor Array functions to the wrapper.
  each(['concat', 'join', 'slice'], function(name) {
    var method = ArrayProto[name];
    _.prototype[name] = function() {
      return result.call(this, method.apply(this._wrapped, arguments));
    };
  });

  _.extend(_.prototype, {

    // Start chaining a wrapped Underscore object.
    chain: function() {
      this._chain = true;
      return this;
    },

    // Extracts the result from a wrapped and chained object.
    value: function() {
      return this._wrapped;
    }

  });

  // AMD registration happens at the end for compatibility with AMD loaders
  // that may not enforce next-turn semantics on modules. Even though general
  // practice for AMD registration is to be anonymous, underscore registers
  // as a named module because, like jQuery, it is a base library that is
  // popular enough to be bundled in a third party lib, but not be part of
  // an AMD load request. Those cases could generate an error when an
  // anonymous define() is called outside of a loader request.
  if (typeof define === 'function' && define.amd) {
    define('underscore', [], function() {
      return _;
    });
  }
}).call(this);

//  Underscore.string
//  (c) 2010 Esa-Matti Suuronen <esa-matti aet suuronen dot org>
//  Underscore.string is freely distributable under the terms of the MIT license.
//  Documentation: https://github.com/epeli/underscore.string
//  Some code is borrowed from MooTools and Alexandru Marasteanu.
//  Version '2.3.2'

!function(root, String){
  'use strict';

  // Defining helper functions.

  var nativeTrim = String.prototype.trim;
  var nativeTrimRight = String.prototype.trimRight;
  var nativeTrimLeft = String.prototype.trimLeft;

  var parseNumber = function(source) { return source * 1 || 0; };

  var strRepeat = function(str, qty){
    if (qty < 1) return '';
    var result = '';
    while (qty > 0) {
      if (qty & 1) result += str;
      qty >>= 1, str += str;
    }
    return result;
  };

  var slice = [].slice;

  var defaultToWhiteSpace = function(characters) {
    if (characters == null)
      return '\\s';
    else if (characters.source)
      return characters.source;
    else
      return '[' + _s.escapeRegExp(characters) + ']';
  };

  // Helper for toBoolean
  function boolMatch(s, matchers) {
    var i, matcher, down = s.toLowerCase();
    matchers = [].concat(matchers);
    for (i = 0; i < matchers.length; i += 1) {
      matcher = matchers[i];
      if (!matcher) continue;
      if (matcher.test && matcher.test(s)) return true;
      if (matcher.toLowerCase() === down) return true;
    }
  }

  var escapeChars = {
    lt: '<',
    gt: '>',
    quot: '"',
    amp: '&',
    apos: "'"
  };

  var reversedEscapeChars = {};
  for(var key in escapeChars) reversedEscapeChars[escapeChars[key]] = key;
  reversedEscapeChars["'"] = '#39';

  // sprintf() for JavaScript 0.7-beta1
  // http://www.diveintojavascript.com/projects/javascript-sprintf
  //
  // Copyright (c) Alexandru Marasteanu <alexaholic [at) gmail (dot] com>
  // All rights reserved.

  var sprintf = (function() {
    function get_type(variable) {
      return Object.prototype.toString.call(variable).slice(8, -1).toLowerCase();
    }

    var str_repeat = strRepeat;

    var str_format = function() {
      if (!str_format.cache.hasOwnProperty(arguments[0])) {
        str_format.cache[arguments[0]] = str_format.parse(arguments[0]);
      }
      return str_format.format.call(null, str_format.cache[arguments[0]], arguments);
    };

    str_format.format = function(parse_tree, argv) {
      var cursor = 1, tree_length = parse_tree.length, node_type = '', arg, output = [], i, k, match, pad, pad_character, pad_length;
      for (i = 0; i < tree_length; i++) {
        node_type = get_type(parse_tree[i]);
        if (node_type === 'string') {
          output.push(parse_tree[i]);
        }
        else if (node_type === 'array') {
          match = parse_tree[i]; // convenience purposes only
          if (match[2]) { // keyword argument
            arg = argv[cursor];
            for (k = 0; k < match[2].length; k++) {
              if (!arg.hasOwnProperty(match[2][k])) {
                throw new Error(sprintf('[_.sprintf] property "%s" does not exist', match[2][k]));
              }
              arg = arg[match[2][k]];
            }
          } else if (match[1]) { // positional argument (explicit)
            arg = argv[match[1]];
          }
          else { // positional argument (implicit)
            arg = argv[cursor++];
          }

          if (/[^s]/.test(match[8]) && (get_type(arg) != 'number')) {
            throw new Error(sprintf('[_.sprintf] expecting number but found %s', get_type(arg)));
          }
          switch (match[8]) {
            case 'b': arg = arg.toString(2); break;
            case 'c': arg = String.fromCharCode(arg); break;
            case 'd': arg = parseInt(arg, 10); break;
            case 'e': arg = match[7] ? arg.toExponential(match[7]) : arg.toExponential(); break;
            case 'f': arg = match[7] ? parseFloat(arg).toFixed(match[7]) : parseFloat(arg); break;
            case 'o': arg = arg.toString(8); break;
            case 's': arg = ((arg = String(arg)) && match[7] ? arg.substring(0, match[7]) : arg); break;
            case 'u': arg = Math.abs(arg); break;
            case 'x': arg = arg.toString(16); break;
            case 'X': arg = arg.toString(16).toUpperCase(); break;
          }
          arg = (/[def]/.test(match[8]) && match[3] && arg >= 0 ? '+'+ arg : arg);
          pad_character = match[4] ? (match[4] == '0' ? '0' : match[4].charAt(1)) : ' ';
          pad_length = match[6] - String(arg).length;
          pad = match[6] ? str_repeat(pad_character, pad_length) : '';
          output.push(match[5] ? arg + pad : pad + arg);
        }
      }
      return output.join('');
    };

    str_format.cache = {};

    str_format.parse = function(fmt) {
      var _fmt = fmt, match = [], parse_tree = [], arg_names = 0;
      while (_fmt) {
        if ((match = /^[^\x25]+/.exec(_fmt)) !== null) {
          parse_tree.push(match[0]);
        }
        else if ((match = /^\x25{2}/.exec(_fmt)) !== null) {
          parse_tree.push('%');
        }
        else if ((match = /^\x25(?:([1-9]\d*)\$|\(([^\)]+)\))?(\+)?(0|'[^$])?(-)?(\d+)?(?:\.(\d+))?([b-fosuxX])/.exec(_fmt)) !== null) {
          if (match[2]) {
            arg_names |= 1;
            var field_list = [], replacement_field = match[2], field_match = [];
            if ((field_match = /^([a-z_][a-z_\d]*)/i.exec(replacement_field)) !== null) {
              field_list.push(field_match[1]);
              while ((replacement_field = replacement_field.substring(field_match[0].length)) !== '') {
                if ((field_match = /^\.([a-z_][a-z_\d]*)/i.exec(replacement_field)) !== null) {
                  field_list.push(field_match[1]);
                }
                else if ((field_match = /^\[(\d+)\]/.exec(replacement_field)) !== null) {
                  field_list.push(field_match[1]);
                }
                else {
                  throw new Error('[_.sprintf] huh?');
                }
              }
            }
            else {
              throw new Error('[_.sprintf] huh?');
            }
            match[2] = field_list;
          }
          else {
            arg_names |= 2;
          }
          if (arg_names === 3) {
            throw new Error('[_.sprintf] mixing positional and named placeholders is not (yet) supported');
          }
          parse_tree.push(match);
        }
        else {
          throw new Error('[_.sprintf] huh?');
        }
        _fmt = _fmt.substring(match[0].length);
      }
      return parse_tree;
    };

    return str_format;
  })();



  // Defining underscore.string

  var _s = {

    VERSION: '2.3.0',

    isBlank: function(str){
      if (str == null) str = '';
      return (/^\s*$/).test(str);
    },

    stripTags: function(str){
      if (str == null) return '';
      return String(str).replace(/<\/?[^>]+>/g, '');
    },

    capitalize : function(str){
      str = str == null ? '' : String(str);
      return str.charAt(0).toUpperCase() + str.slice(1);
    },

    chop: function(str, step){
      if (str == null) return [];
      str = String(str);
      step = ~~step;
      return step > 0 ? str.match(new RegExp('.{1,' + step + '}', 'g')) : [str];
    },

    clean: function(str){
      return _s.strip(str).replace(/\s+/g, ' ');
    },

    count: function(str, substr){
      if (str == null || substr == null) return 0;

      str = String(str);
      substr = String(substr);

      var count = 0,
        pos = 0,
        length = substr.length;

      while (true) {
        pos = str.indexOf(substr, pos);
        if (pos === -1) break;
        count++;
        pos += length;
      }

      return count;
    },

    chars: function(str) {
      if (str == null) return [];
      return String(str).split('');
    },

    swapCase: function(str) {
      if (str == null) return '';
      return String(str).replace(/\S/g, function(c){
        return c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase();
      });
    },

    escapeHTML: function(str) {
      if (str == null) return '';
      return String(str).replace(/[&<>"']/g, function(m){ return '&' + reversedEscapeChars[m] + ';'; });
    },

    unescapeHTML: function(str) {
      if (str == null) return '';
      return String(str).replace(/\&([^;]+);/g, function(entity, entityCode){
        var match;

        if (entityCode in escapeChars) {
          return escapeChars[entityCode];
        } else if (match = entityCode.match(/^#x([\da-fA-F]+)$/)) {
          return String.fromCharCode(parseInt(match[1], 16));
        } else if (match = entityCode.match(/^#(\d+)$/)) {
          return String.fromCharCode(~~match[1]);
        } else {
          return entity;
        }
      });
    },

    escapeRegExp: function(str){
      if (str == null) return '';
      return String(str).replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');
    },

    splice: function(str, i, howmany, substr){
      var arr = _s.chars(str);
      arr.splice(~~i, ~~howmany, substr);
      return arr.join('');
    },

    insert: function(str, i, substr){
      return _s.splice(str, i, 0, substr);
    },

    include: function(str, needle){
      if (needle === '') return true;
      if (str == null) return false;
      return String(str).indexOf(needle) !== -1;
    },

    join: function() {
      var args = slice.call(arguments),
        separator = args.shift();

      if (separator == null) separator = '';

      return args.join(separator);
    },

    lines: function(str) {
      if (str == null) return [];
      return String(str).split("\n");
    },

    reverse: function(str){
      return _s.chars(str).reverse().join('');
    },

    startsWith: function(str, starts){
      if (starts === '') return true;
      if (str == null || starts == null) return false;
      str = String(str); starts = String(starts);
      return str.length >= starts.length && str.slice(0, starts.length) === starts;
    },

    endsWith: function(str, ends){
      if (ends === '') return true;
      if (str == null || ends == null) return false;
      str = String(str); ends = String(ends);
      return str.length >= ends.length && str.slice(str.length - ends.length) === ends;
    },

    succ: function(str){
      if (str == null) return '';
      str = String(str);
      return str.slice(0, -1) + String.fromCharCode(str.charCodeAt(str.length-1) + 1);
    },

    titleize: function(str){
      if (str == null) return '';
      str  = String(str).toLowerCase();
      return str.replace(/(?:^|\s|-)\S/g, function(c){ return c.toUpperCase(); });
    },

    camelize: function(str){
      return _s.trim(str).replace(/[-_\s]+(.)?/g, function(match, c){ return c ? c.toUpperCase() : ""; });
    },

    underscored: function(str){
      return _s.trim(str).replace(/([a-z\d])([A-Z]+)/g, '$1_$2').replace(/[-\s]+/g, '_').toLowerCase();
    },

    dasherize: function(str){
      return _s.trim(str).replace(/([A-Z])/g, '-$1').replace(/[-_\s]+/g, '-').toLowerCase();
    },

    classify: function(str){
      return _s.titleize(String(str).replace(/[\W_]/g, ' ')).replace(/\s/g, '');
    },

    humanize: function(str){
      return _s.capitalize(_s.underscored(str).replace(/_id$/,'').replace(/_/g, ' '));
    },

    trim: function(str, characters){
      if (str == null) return '';
      if (!characters && nativeTrim) return nativeTrim.call(str);
      characters = defaultToWhiteSpace(characters);
      return String(str).replace(new RegExp('\^' + characters + '+|' + characters + '+$', 'g'), '');
    },

    ltrim: function(str, characters){
      if (str == null) return '';
      if (!characters && nativeTrimLeft) return nativeTrimLeft.call(str);
      characters = defaultToWhiteSpace(characters);
      return String(str).replace(new RegExp('^' + characters + '+'), '');
    },

    rtrim: function(str, characters){
      if (str == null) return '';
      if (!characters && nativeTrimRight) return nativeTrimRight.call(str);
      characters = defaultToWhiteSpace(characters);
      return String(str).replace(new RegExp(characters + '+$'), '');
    },

    truncate: function(str, length, truncateStr){
      if (str == null) return '';
      str = String(str); truncateStr = truncateStr || '...';
      length = ~~length;
      return str.length > length ? str.slice(0, length) + truncateStr : str;
    },

    /**
     * _s.prune: a more elegant version of truncate
     * prune extra chars, never leaving a half-chopped word.
     * @author github.com/rwz
     */
    prune: function(str, length, pruneStr){
      if (str == null) return '';

      str = String(str); length = ~~length;
      pruneStr = pruneStr != null ? String(pruneStr) : '...';

      if (str.length <= length) return str;

      var tmpl = function(c){ return c.toUpperCase() !== c.toLowerCase() ? 'A' : ' '; },
        template = str.slice(0, length+1).replace(/.(?=\W*\w*$)/g, tmpl); // 'Hello, world' -> 'HellAA AAAAA'

      if (template.slice(template.length-2).match(/\w\w/))
        template = template.replace(/\s*\S+$/, '');
      else
        template = _s.rtrim(template.slice(0, template.length-1));

      return (template+pruneStr).length > str.length ? str : str.slice(0, template.length)+pruneStr;
    },

    words: function(str, delimiter) {
      if (_s.isBlank(str)) return [];
      return _s.trim(str, delimiter).split(delimiter || /\s+/);
    },

    pad: function(str, length, padStr, type) {
      str = str == null ? '' : String(str);
      length = ~~length;

      var padlen  = 0;

      if (!padStr)
        padStr = ' ';
      else if (padStr.length > 1)
        padStr = padStr.charAt(0);

      switch(type) {
        case 'right':
          padlen = length - str.length;
          return str + strRepeat(padStr, padlen);
        case 'both':
          padlen = length - str.length;
          return strRepeat(padStr, Math.ceil(padlen/2)) + str
                  + strRepeat(padStr, Math.floor(padlen/2));
        default: // 'left'
          padlen = length - str.length;
          return strRepeat(padStr, padlen) + str;
        }
    },

    lpad: function(str, length, padStr) {
      return _s.pad(str, length, padStr);
    },

    rpad: function(str, length, padStr) {
      return _s.pad(str, length, padStr, 'right');
    },

    lrpad: function(str, length, padStr) {
      return _s.pad(str, length, padStr, 'both');
    },

    sprintf: sprintf,

    vsprintf: function(fmt, argv){
      argv.unshift(fmt);
      return sprintf.apply(null, argv);
    },

    toNumber: function(str, decimals) {
      if (!str) return 0;
      str = _s.trim(str);
      if (!str.match(/^-?\d+(?:\.\d+)?$/)) return NaN;
      return parseNumber(parseNumber(str).toFixed(~~decimals));
    },

    numberFormat : function(number, dec, dsep, tsep) {
      if (isNaN(number) || number == null) return '';

      number = number.toFixed(~~dec);
      tsep = typeof tsep == 'string' ? tsep : ',';

      var parts = number.split('.'), fnums = parts[0],
        decimals = parts[1] ? (dsep || '.') + parts[1] : '';

      return fnums.replace(/(\d)(?=(?:\d{3})+$)/g, '$1' + tsep) + decimals;
    },

    strRight: function(str, sep){
      if (str == null) return '';
      str = String(str); sep = sep != null ? String(sep) : sep;
      var pos = !sep ? -1 : str.indexOf(sep);
      return ~pos ? str.slice(pos+sep.length, str.length) : str;
    },

    strRightBack: function(str, sep){
      if (str == null) return '';
      str = String(str); sep = sep != null ? String(sep) : sep;
      var pos = !sep ? -1 : str.lastIndexOf(sep);
      return ~pos ? str.slice(pos+sep.length, str.length) : str;
    },

    strLeft: function(str, sep){
      if (str == null) return '';
      str = String(str); sep = sep != null ? String(sep) : sep;
      var pos = !sep ? -1 : str.indexOf(sep);
      return ~pos ? str.slice(0, pos) : str;
    },

    strLeftBack: function(str, sep){
      if (str == null) return '';
      str += ''; sep = sep != null ? ''+sep : sep;
      var pos = str.lastIndexOf(sep);
      return ~pos ? str.slice(0, pos) : str;
    },

    toSentence: function(array, separator, lastSeparator, serial) {
      separator = separator || ', ';
      lastSeparator = lastSeparator || ' and ';
      var a = array.slice(), lastMember = a.pop();

      if (array.length > 2 && serial) lastSeparator = _s.rtrim(separator) + lastSeparator;

      return a.length ? a.join(separator) + lastSeparator + lastMember : lastMember;
    },

    toSentenceSerial: function() {
      var args = slice.call(arguments);
      args[3] = true;
      return _s.toSentence.apply(_s, args);
    },

    slugify: function(str) {
      if (str == null) return '';

      var from  = "ąàáäâãåæăćęèéëêìíïîłńòóöôõøśșțùúüûñçżź",
          to    = "aaaaaaaaaceeeeeiiiilnoooooosstuuuunczz",
          regex = new RegExp(defaultToWhiteSpace(from), 'g');

      str = String(str).toLowerCase().replace(regex, function(c){
        var index = from.indexOf(c);
        return to.charAt(index) || '-';
      });

      return _s.dasherize(str.replace(/[^\w\s-]/g, ''));
    },

    surround: function(str, wrapper) {
      return [wrapper, str, wrapper].join('');
    },

    quote: function(str, quoteChar) {
      return _s.surround(str, quoteChar || '"');
    },

    unquote: function(str, quoteChar) {
      quoteChar = quoteChar || '"';
      if (str[0] === quoteChar && str[str.length-1] === quoteChar)
        return str.slice(1,str.length-1);
      else return str;
    },

    exports: function() {
      var result = {};

      for (var prop in this) {
        if (!this.hasOwnProperty(prop) || prop.match(/^(?:include|contains|reverse)$/)) continue;
        result[prop] = this[prop];
      }

      return result;
    },

    repeat: function(str, qty, separator){
      if (str == null) return '';

      qty = ~~qty;

      // using faster implementation if separator is not needed;
      if (separator == null) return strRepeat(String(str), qty);

      // this one is about 300x slower in Google Chrome
      for (var repeat = []; qty > 0; repeat[--qty] = str) {}
      return repeat.join(separator);
    },

    naturalCmp: function(str1, str2){
      if (str1 == str2) return 0;
      if (!str1) return -1;
      if (!str2) return 1;

      var cmpRegex = /(\.\d+)|(\d+)|(\D+)/g,
        tokens1 = String(str1).toLowerCase().match(cmpRegex),
        tokens2 = String(str2).toLowerCase().match(cmpRegex),
        count = Math.min(tokens1.length, tokens2.length);

      for(var i = 0; i < count; i++) {
        var a = tokens1[i], b = tokens2[i];

        if (a !== b){
          var num1 = parseInt(a, 10);
          if (!isNaN(num1)){
            var num2 = parseInt(b, 10);
            if (!isNaN(num2) && num1 - num2)
              return num1 - num2;
          }
          return a < b ? -1 : 1;
        }
      }

      if (tokens1.length === tokens2.length)
        return tokens1.length - tokens2.length;

      return str1 < str2 ? -1 : 1;
    },

    levenshtein: function(str1, str2) {
      if (str1 == null && str2 == null) return 0;
      if (str1 == null) return String(str2).length;
      if (str2 == null) return String(str1).length;

      str1 = String(str1); str2 = String(str2);

      var current = [], prev, value;

      for (var i = 0; i <= str2.length; i++)
        for (var j = 0; j <= str1.length; j++) {
          if (i && j)
            if (str1.charAt(j - 1) === str2.charAt(i - 1))
              value = prev;
            else
              value = Math.min(current[j], current[j - 1], prev) + 1;
          else
            value = i + j;

          prev = current[j];
          current[j] = value;
        }

      return current.pop();
    },

    toBoolean: function(str, trueValues, falseValues) {
      if (typeof str === "number") str = "" + str;
      if (typeof str !== "string") return !!str;
      str = _s.trim(str);
      if (boolMatch(str, trueValues || ["true", "1"])) return true;
      if (boolMatch(str, falseValues || ["false", "0"])) return false;
    }
  };

  // Aliases

  _s.strip    = _s.trim;
  _s.lstrip   = _s.ltrim;
  _s.rstrip   = _s.rtrim;
  _s.center   = _s.lrpad;
  _s.rjust    = _s.lpad;
  _s.ljust    = _s.rpad;
  _s.contains = _s.include;
  _s.q        = _s.quote;
  _s.toBool   = _s.toBoolean;

  // Exporting

  // CommonJS module is defined
  if (typeof exports !== 'undefined') {
    if (typeof module !== 'undefined' && module.exports)
      module.exports = _s;

    exports._s = _s;
  }

  // Register as a named module with AMD.
  if (typeof define === 'function' && define.amd)
    define('underscore.string', [], function(){ return _s; });


  // Integrate with Underscore.js if defined
  // or create our own underscore object.
  root._ = root._ || {};
  root._.string = root._.str = _s;
}(this, String);

(function(){var a,b,c,d=[].slice;if(a=function(){function a(){}return a.VERSION="0.1.0",a.RESET="[0m",a.BLACK="[030m",a.RED="[031m",a.GREEN="[032m",a.YELLOW="[033m",a.BLUE="[034m",a.PURPLE="[035m",a.CYAN="[036m",a.GREY="[037m",a.BLACK_BOLD="[130m",a.RED_BOLD="[131m",a.GREEN_BOLD="[132m",a.YELLOW_BOLD="[133m",a.BLUE_BOLD="[134m",a.PURPLE_BOLD="[135m",a.CYAN_BOLD="[136m",a.GREY_BOLD="[137m",a.BLACK_UNDERLINED="[430m",a.RED_UNDERLINED="[431m",a.GREEN_UNDERLINED="[432m",a.YELLOW_UNDERLINED="[433m",a.BLUE_UNDERLINED="[434m",a.PURPLE_UNDERLINED="[435m",a.CYAN_UNDERLINED="[436m",a.WHITE_UNDERLINED="[437m",a.BACKGROUND_BLACK="[40m",a.BACKGROUND_RED="[41m",a.BACKGROUND_GREEN="[42m",a.BACKGROUND_YELLOW="[43m",a.BACKGROUND_BLUE="[44m",a.BACKGROUND_PURPLE="[45m",a.BACKGROUND_CYAN="[46m",a.BACKGROUND_WHITE="[47m",a.LEVEL_ALL=0,a.LEVEL_INFO=1,a.LEVEL_WARN=2,a.LEVEL_ERROR=3,a.LEVEL_NONE=4,a.level=4,a.logDir="/tmp",a.colorize=!0,a.logFile="extendscript-console.log",a.prototype._timers={},a.prototype._timerLaps={},a.prototype.log=function(){var b;if(b=1<=arguments.length?d.call(arguments,0):[],a.level<=a.LEVEL_ALL)this._log(b);return this},a.prototype.dir=function(){var b;if(b=1<=arguments.length?d.call(arguments,0):[],a.level<=a.LEVEL_ALL)this._log(b);return this},a.prototype.info=function(){var b;if(b=1<=arguments.length?d.call(arguments,0):[],a.level<=a.LEVEL_INFO)this._log(b,a.YELLOW);return this},a.prototype.warn=function(){var b;if(b=1<=arguments.length?d.call(arguments,0):[],a.level<=a.LEVEL_WARN)this._log(b,a.CYAN_BOLD);return this},a.prototype.error=function(){var b;if(b=1<=arguments.length?d.call(arguments,0):[],a.level<=a.LEVEL_ERROR)this._log(b,a.RED);return this},a.prototype.profile=function(){var b;if(b=1<=arguments.length?d.call(arguments,0):[],a.level<=a.LEVEL_ALL)this._log(b,a.PURPLE);return this},a.prototype.success=function(){var b;if(b=1<=arguments.length?d.call(arguments,0):[],a.level<=a.LEVEL_ALL)this._log(b,a.GREEN);return this},a.prototype.time=function(b){if(a.level<=a.LEVEL_ALL)this._timers[b]=(new Date).getTime(),this._timerLaps[b]=(new Date).getTime();return this},a.prototype.timeLap=function(b,c){var d,e;if(a.level<=a.LEVEL_ALL){if(d=(new Date).getTime(),!(e=this._timers[b]))return this;this.profile(this._format(b+": "+c)+" ["+(d-this._timerLaps[b])+"ms | total: "+(d-e)+"ms]"),this._timerLaps[b]=d}return this},a.prototype.timeEnd=function(b){var c;if(a.level<=a.LEVEL_ALL){if(!(c=this._timers[b]))return this;this.profile(this._format(b)+" ["+((new Date).getTime()-c)+"ms]"),delete this._timerLaps[b],delete this._timers[b]}return this},a.prototype._log=function(b,c){var d,e,f,g,h;if(null==c)c="";for(d=this,h=[],f=0,g=b.length;g>f;f++){if(e=b[f],e===Object(e))e=JSON.stringify(e);if(a.colorize)e=d._colorize(e,c);h.push(d._write(e))}return h},a.prototype._write=function(b){var c,d;if(d=new File(a.logDir+"/"+a.logFile),d.encoding="UTF-8",d.lineFeed="unix",!d.exists)try{d.open("w"),d.close()}catch(e){return c=e,$.writeln("ERROR='"+d.error+"', failed to create log file."),!1}try{return d.open("a"),d.writeln(b.toString()),d.close(),!0}catch(e){return c=e,$.writeln("ERROR='"+d.error+"', Log() failed to write '"+b+"' to log file."),!1}},a.prototype._colorize=function(b,c){return c+b+a.RESET},a.prototype._format=function(a,b,c){if(null==b)b=".";if(null==c)c=60;for(;a.length<c;)a+=b;return a},a}(),c=this,b=new a,"undefined"!=typeof exports&&null!==exports){if("undefined"!=typeof module&&null!==module&&null!=module.exports)module.exports.console=b,module.exports.Console=a;exports.console=b,exports.Console=a}else if(null==c.console)c.console=b,c.Console=a}).call(this);
var owlstars={event:{},palette:{},photoshop:{}};(function(){var e={}.hasOwnProperty,t=function(t,r){function o(){this.constructor=t};for(var n in r)if(e.call(r,n))t[n]=r[n];return o.prototype=r.prototype,t.prototype=new o,t.__super__=r.prototype,t};owlstars.photoshop.Layer=function(){function e(e,t,r){if(null==r)r=null;this._kind=t,this._index=e,this._parent=r,this._desc=this._getLayerDescriptor(),this._id=this._desc.getInteger(charIDToTypeID("LyrI")),this._name=this._desc.getString(charIDToTypeID("Nm  "))};return e.KIND_TEXT="text",e.KIND_GROUP="group",e.KIND_NORMAL="normal",e.KIND_SHAPE="shape",e.KIND_DOCUMENT="document",e.KIND_BACKGROUND="background",e.KIND_ADJUSTMENT="adjustment",e.KIND_SECTION_END="sectionEnd",e.KIND_SMART_OBJECT="smartObject",e.KIND_CLIPPING_MASK="clippingMask",e.prototype._id=null,e.prototype._name=null,e.prototype._kind=null,e.prototype._index=null,e.prototype._bounds=null,e.prototype._parent=null,e.prototype._desc=null,e.prototype._latinMap={\u00c4:"A",\u00e4:"a",\u00d6:"O",\u00f6:"o",\u00dc:"U",\u00fc:"u"},e.prototype.getId=function(){return this._id},e.prototype.getName=function(){return this._name},e.prototype.getSanitizedName=function(){var e;return e=this.getName(),e=_.str.strLeftBack(e,"."),e=e.replace(/[^a-zA-Z0-9\-_ ]/g,function(e){return function(t){return e._latinMap[t]||t}}(this)),e=_.str.camelize(e)},e.prototype.getIndex=function(){return this._index},e.prototype.getParent=function(){return this._parent},e.prototype.getKind=function(){return this._kind},e.prototype.getVisible=function(){return this._desc.getBoolean(charIDToTypeID("Vsbl"))},e.prototype.setVisible=function(e){var t,r,o;return r=new ActionList,t=new ActionDescriptor,o=this._getLayerReference(this.getIndex()),e=e?"Shw ":"Hd  ",r.putReference(o),t.putList(charIDToTypeID("null"),r),executeAction(charIDToTypeID(e),t,DialogModes.NO),this},e.prototype.getOpacity=function(){return this._desc.getInteger(charIDToTypeID("Opct"))},e.prototype.select=function(){var e;return e=new ActionDescriptor,e.putReference(charIDToTypeID("null"),this._getLayerReference()),executeAction(charIDToTypeID("slct"),e,DialogModes.NO),this},e.prototype.duplicateToNewDocument=function(e,t){var r,o;return r=new ActionDescriptor,o=new ActionReference,o.putClass(charIDToTypeID("Dcmn")),r.putReference(charIDToTypeID("null"),o),r.putString(charIDToTypeID("Nm  "),e),r.putReference(charIDToTypeID("Usng"),this._getLayerReference()),r.putString(charIDToTypeID("LyrN"),t),r.putInteger(charIDToTypeID("Vrsn"),5),executeAction(charIDToTypeID("Mk  "),r,DialogModes.NO),this},e.prototype.hasEffects=function(){return owlstars.document.Layer.hasEffects(this._desc)},e.prototype._getLayerDescriptor=function(){return owlstars.photoshop.Layer.getLayerDescriptor(this.getIndex())},e.prototype._getLayerReference=function(){return owlstars.photoshop.Layer.getLayerReference(this.getIndex())},e.prototype._getLayerKind=function(){return owlstars.photoshop.Layer.getLayerKind(this.getIndex())},e.getLayerDescriptor=function(e){return executeActionGet(this.getLayerReference(e))},e.getLayerReference=function(e){var t;return t=new ActionReference,t.putIndex(charIDToTypeID("Lyr "),e),t},e.getLayerKind=function(e){var t,r,o;switch(r=null,t=this.getLayerDescriptor(e),o=typeIDToStringID(t.getEnumerationValue(stringIDToTypeID("layerSection"))),!0){case"layerSectionStart"===o:r=this.KIND_GROUP;break;case"layerSectionEnd"===o:r=this.KIND_SECTION_END;break;case t.getBoolean(stringIDToTypeID("background")):r=this.KIND_BACKGROUND;break;case t.hasKey(stringIDToTypeID("group"))&&t.getBoolean(stringIDToTypeID("group")):r=this.KIND_CLIPPING_MASK;break;case t.hasKey(stringIDToTypeID("textKey")):r=this.KIND_TEXT;break;case t.hasKey(stringIDToTypeID("smartObject")):r=this.KIND_SMART_OBJECT;break;case t.hasKey(stringIDToTypeID("hasVectorMask"))&&t.getBoolean(stringIDToTypeID("hasVectorMask")):r=this.KIND_SHAPE;break;case t.hasKey(stringIDToTypeID("adjustment")):r=this.KIND_ADJUSTMENT;break;default:r=this.KIND_NORMAL};return r},e.isWorkingLayer=function(e){if(!e.getVisible())return!1;if(!_.contains([this.KIND_NORMAL,this.KIND_SHAPE,this.KIND_SMART_OBJECT,this.KIND_TEXT,this.KIND_GROUP],e.getKind()))return!1;if(_.contains([this.KIND_NORMAL,this.KIND_SHAPE,this.KIND_SMART_OBJECT,this.KIND_TEXT],e.getKind())&&e.getBounds()===!1)return!1;if(_.contains([this.KIND_GROUP],e.getKind())&&0===e.getAllWorkingArtLayers().length)return!1;else return!0},e}(),owlstars.photoshop.LayerSet=function(e){function r(e,t,o){if(null==o)o=null;r.__super__.constructor.call(this,e,t,o),this._artLayers=[],this._layerSets=[]};return t(r,e),r.prototype._artLayers=null,r.prototype._layerSets=null,r.prototype.getArtLayers=function(){return this._artLayers},r.prototype.getLayerSets=function(){return this._layerSets},r.prototype.getWorkingArtLayers=function(){var e,t,r,o,n;for(e=[],n=this.getArtLayers(),r=0,o=n.length;o>r;r++)if(t=n[r],owlstars.photoshop.Layer.isWorkingLayer(t))e.push(t);else;return e},r.prototype.getAllArtLayers=function(){var e,t,r,o,n;for(t=this.getArtLayers(),n=this.getLayerSets(),r=0,o=n.length;o>r;r++)e=n[r],t=t.concat(e.getAllArtLayers());return t},r.prototype.getAllWorkingArtLayers=function(){var e,t,r,o,n;for(t=this.getWorkingArtLayers(),n=this.getWorkingLayerSets(),r=0,o=n.length;o>r;r++)e=n[r],t=t.concat(e.getAllWorkingArtLayers());return t},r.prototype.getWorkingLayerSets=function(){var e,t,r,o,n;for(e=[],n=this.getLayerSets(),r=0,o=n.length;o>r;r++)if(t=n[r],owlstars.photoshop.Layer.isWorkingLayer(t))e.push(t);else;return e},r.prototype.getWorkingBounds=function(){var e,t,r,o,n;for(e=[],n=this.getWorkingArtLayers(),r=0,o=n.length;o>r;r++)t=n[r],e=t.getBounds(),e[0]=Number(e[0])||Math.min(e[0],Number(e[0])),e[1]=Number(e[1])||Math.min(e[1],Number(e[1])),e[2]=Number(e[2])||Math.max(e[2],Number(e[2])),e[3]=Number(e[3])||Math.max(e[3],Number(e[3]));return e},r.prototype.ungroup=function(){var e;return e=new ActionDescriptor,e.putReference(charIDToTypeID("null"),this._getLayerReference()),executeAction(stringIDToTypeID("ungroupLayersEvent"),e,DialogModes.NO),this},r}(owlstars.photoshop.Layer),owlstars.event.Emitter=function(){function e(){};return e.prototype._events={},e.prototype.addListener=function(e,t,r,o){if(null==o)o=!1;if(!this._events.hasOwnProperty(e))this._events[e]=[];return this._events[e].push(new owlstars.Event(e,t,r,o,this)),this.emit("newListener",e,t,r,o),this},e.prototype.removeListener=function(e,t,r){if(this.eachListener(e,function(o,n){if(o.listener===t&&(!r||o.scope===r))return this._events[e].splice(n,1);else return void 0}),this._events[e]&&0===this._events[e].length)delete this._events[e];return this},e.prototype.removeAllListeners=function(e){if(e&&this._events.hasOwnProperty(e))delete this._events[e];else if(!e)this._events={};return this},e.prototype.listeners=function(e){var t;if(this._events.hasOwnProperty(e))return t=[],this.eachListener(e,function(e){return t.push(e.listener)}),t;else return[]},e.prototype.emit=function(e){var t;return t=Array.prototype.slice.call(arguments,1),this.eachListener(e,function(e){return e.fire(t)}),this},e.prototype.eachListener=function(e,t){var r,o,n;if(r=0,n=null,o=null,this._events.hasOwnProperty(e))for(o=this._events[e];r<o.length;)t.call(this,o[r],r),r++;return this},e}(),owlstars.Event=function(){function e(e,t,r,o,n){this.type=e,this.listener=t,this.scope=r,this.once=o,this.instance=n};return e.prototype.type=null,e.prototype.listener=null,e.prototype.scope=null,e.prototype.once=null,e.prototype.instance=null,e.prototype.fire=function(e){if(this.listener.apply(this.scope||this.instance,e),this.once)return this.instance.removeListener(this.type,this.listener,this.scope),!1;else return!0},e}(),owlstars.palette.ProgressBar=function(){function e(){};return e.prototype._windowRef=null,e.prototype.show=function(e,t,r,o){if(null==t)t="Progress";if(null==r)r=0;if(null==o)o=100;return this._windowRef=new Window("palette",null,[150,150,600,265],{borderless:!0}),this._windowRef.pnl=this._windowRef.add("panel",[10,10,440,100],e),this._windowRef.pnl.progBarLabel=this._windowRef.pnl.add("statictext",[20,20,320,35],t),this._windowRef.pnl.progBar=this._windowRef.pnl.add("progressbar",[20,35,410,60],r,o),this._windowRef.center(),this._windowRef.show(),this},e.prototype.close=function(){return this._windowRef.close()},e.prototype.addProgress=function(e){return this.setProgress(this._windowRef.pnl.progBar.value+e),this},e.prototype.setProgress=function(e){return e=Math.min(e,this._windowRef.pnl.progBar.maxvalue),this._windowRef.pnl.progBar.value=e,this._windowRef.update(),this},e}(),owlstars.photoshop.ArtLayer=function(e){function r(e,t,o){if(null==o)o=null;r.__super__.constructor.call(this,e,t,o)};return t(r,e),r.prototype.getX=function(){return parseInt(this.getBounds()[0])},r.prototype.getXUnit=function(e){var t;if(null==e)e="px";if(0===(t=this.getX()))return 0;else return"-"+t+e},r.prototype.getY=function(){return parseInt(this.getBounds()[1])},r.prototype.getYUnit=function(e){var t;if(null==e)e="px";if(0===(t=this.getY()))return 0;else return"-"+t+e},r.prototype.getWidth=function(){return parseInt(this.getBounds()[2])-parseInt(this.getBounds()[0])},r.prototype.getWidthUnit=function(e){var t;if(null==e)e="px";if(0===(t=this.getWidth()))return 0;else return t+e},r.prototype.getHeight=function(){return parseInt(this.getBounds()[3])-parseInt(this.getBounds()[1])},r.prototype.getHeightUnit=function(e){var t;if(null==e)e="px";if(0===(t=this.getHeight()))return 0;else return t+e},r.prototype.getBounds=function(){var e,t;if(null!=this._bounds)return this._bounds;else return t=new Array,e=this._desc.getObjectValue(stringIDToTypeID("bounds")),t.push(e.getDouble(charIDToTypeID("Left"))),t.push(e.getDouble(charIDToTypeID("Top "))),t.push(e.getDouble(charIDToTypeID("Rght"))),t.push(e.getDouble(charIDToTypeID("Btom"))),this._bounds=1===_.uniq(t).length&&0===t[0]?!1:t},r.prototype.getFillOpacity=function(){return this._desc.getInteger(stringIDToTypeID("fillOpacity"))},r.prototype.addAlphaMask=function(){var e,t,r,o,n,s,i,p,a,c,u,h,l;if(this.getKind()===owlstars.photoshop.Layer.KIND_SMART_OBJECT)return this;else return e=new ActionDescriptor,a=new ActionReference,a.putProperty(charIDToTypeID("Chnl"),charIDToTypeID("fsel")),e.putReference(charIDToTypeID("null"),a),c=new ActionReference,c.putEnumerated(charIDToTypeID("Chnl"),charIDToTypeID("Chnl"),charIDToTypeID("Trsp")),e.putReference(charIDToTypeID("T   "),c),executeAction(charIDToTypeID("setd"),e,DialogModes.NO),executeAction(charIDToTypeID("Invs"),void 0,DialogModes.NO),t=new ActionDescriptor,u=new ActionReference,u.putProperty(charIDToTypeID("Prpr"),charIDToTypeID("QucM")),u.putEnumerated(charIDToTypeID("Dcmn"),charIDToTypeID("Ordn"),charIDToTypeID("Trgt")),t.putReference(charIDToTypeID("null"),u),executeAction(charIDToTypeID("setd"),t,DialogModes.NO),r=new ActionDescriptor,r.putInteger(charIDToTypeID("Lvl "),255),executeAction(charIDToTypeID("Thrs"),r,DialogModes.NO),o=new ActionDescriptor,h=new ActionReference,h.putProperty(charIDToTypeID("Prpr"),charIDToTypeID("QucM")),h.putEnumerated(charIDToTypeID("Dcmn"),charIDToTypeID("Ordn"),charIDToTypeID("Trgt")),o.putReference(charIDToTypeID("null"),h),executeAction(charIDToTypeID("Cler"),o,DialogModes.NO),p=n=new ActionDescriptor,s=new ActionDescriptor,s.putUnitDouble(charIDToTypeID("Hrzn"),charIDToTypeID("#Pxl"),294),s.putUnitDouble(charIDToTypeID("Vrtc"),charIDToTypeID("#Pxl"),232),n.putObject(charIDToTypeID("From"),charIDToTypeID("Pnt "),s),n.putInteger(charIDToTypeID("Tlrn"),32),n.putBoolean(charIDToTypeID("AntA"),!0),n.putEnumerated(charIDToTypeID("Usng"),charIDToTypeID("FlCn"),charIDToTypeID("FrgC")),n.putBoolean(charIDToTypeID("Cntg"),!1),executeAction(charIDToTypeID("Fl  "),n,DialogModes.NO),executeAction(charIDToTypeID("Invs"),void 0,DialogModes.NO),i=new ActionDescriptor,i.putClass(charIDToTypeID("Nw  "),charIDToTypeID("Chnl")),l=new ActionReference,l.putEnumerated(charIDToTypeID("Chnl"),charIDToTypeID("Chnl"),charIDToTypeID("Msk ")),i.putReference(charIDToTypeID("At  "),l),i.putEnumerated(charIDToTypeID("Usng"),charIDToTypeID("UsrM"),charIDToTypeID("RvlS")),executeAction(charIDToTypeID("Mk  "),i,DialogModes.NO),this},r.prototype.isRasterizeAble=function(){var e;return e=[owlstars.photoshop.Layer.KIND_TEXT,owlstars.photoshop.Layer.KIND_SHAPE,owlstars.photoshop.Layer.KIND_SMART_OBJECT],_.contains(e,this.getKind())},r.prototype.rasterize=function(){var e;if(!this.isRasterizeAble())return this;else return e=new ActionDescriptor,e.putReference(charIDToTypeID("null"),this._getLayerReference()),executeAction(stringIDToTypeID("rasterizeLayer"),e,DialogModes.NO),this._kind=owlstars.photoshop.Layer.KIND_NORMAL,this},r}(owlstars.photoshop.Layer),owlstars.photoshop.Document=function(e){function r(e){this._obj=e,this._id=e.id,this._name=e.name,this._desc=this._getDocumentDescriptor(),this._kind=owlstars.photoshop.Layer.KIND_DOCUMENT,this._parent=null,this._index=0,this.updateLayers()};return t(r,e),r._suspendHistoryObject=null,r.prototype._obj=null,r.prototype.getObj=function(){return this._obj},r.prototype.getNumLayers=function(){return this._desc.getInteger(charIDToTypeID("NmbL"))},r.prototype.getWidth=function(){return parseInt(this.getObj().width)},r.prototype.getWidthUnit=function(e){var t;if(null==e)e="px";if(0===(t=this.getWidth()))return 0;else return t+e},r.prototype.getHeight=function(){return parseInt(this.getObj().height)},r.prototype.getHeightUnit=function(e){var t;if(null==e)e="px";if(0===(t=this.getHeight()))return 0;else return t+e},r.prototype.close=function(){var e;return e=new ActionDescriptor,e.putEnumerated(charIDToTypeID("Svng"),charIDToTypeID("YsN "),charIDToTypeID("N   ")),executeAction(charIDToTypeID("Cls "),e,DialogModes.NO)},r.prototype.duplicate=function(e){var t,r;return r=new ActionReference,t=new ActionDescriptor,r.putIdentifier(charIDToTypeID("Dcmn"),this.getId()),t.putReference(charIDToTypeID("null"),r),t.putString(charIDToTypeID("Nm  "),e),executeAction(charIDToTypeID("Dplc"),t,DialogModes.NO),this},r.prototype.rasterizeAllLayers=function(){var e,t,r,o;for(o=this.getAllArtLayers(),t=0,r=o.length;r>t;t++)e=o[t],e.rasterize();return this},r.prototype.getBackgroundLayer=function(){var e,t;if(e=this.getArtLayers(),0===e.length)return null;if(t=e[e.length-1],t.getKind()===owlstars.photoshop.Layer.KIND_BACKGROUND)return t;else return null},r.prototype.newBackgroundLayer=function(){var e,t,r;return e=new ActionDescriptor,t=new ActionReference,t.putClass(charIDToTypeID("BckL")),e.putReference(charIDToTypeID("null"),t),r=new ActionReference,r.putEnumerated(charIDToTypeID("Lyr "),charIDToTypeID("Ordn"),charIDToTypeID("Trgt")),e.putReference(charIDToTypeID("Usng"),r),executeAction(charIDToTypeID("Mk  "),e,DialogModes.NO),this},r.prototype.trim=function(e,t,r,o,n){var s;if(null==e)e=!0;if(null==t)t=!0;if(null==r)r=!0;if(null==o)o=!0;if(null==n)n="Trns";return s=new ActionDescriptor,s.putEnumerated(stringIDToTypeID("trimBasedOn"),stringIDToTypeID("trimBasedOn"),charIDToTypeID(n)),s.putBoolean(charIDToTypeID("Top "),e),s.putBoolean(charIDToTypeID("Btom"),r),s.putBoolean(charIDToTypeID("Left"),t),s.putBoolean(charIDToTypeID("Rght"),o),executeAction(stringIDToTypeID("trim"),s,DialogModes.NO),this},r.prototype.setImageSize=function(e,t,r){var o;if(null==r)r="#Prc";return o=new ActionDescriptor,o.putUnitDouble(charIDToTypeID("Wdth"),charIDToTypeID(r),e),o.putUnitDouble(charIDToTypeID("Hght"),charIDToTypeID(r),t),o.putEnumerated(charIDToTypeID("Intr"),charIDToTypeID("Intp"),stringIDToTypeID("automaticInterpolation")),executeAction(charIDToTypeID("ImgS"),o,DialogModes.NO),this},r.prototype.revealAll=function(){return executeAction(charIDToTypeID("RvlA"),new ActionDescriptor,DialogModes.NO),this},r.prototype.addPosterizeAdjustmentLayer=function(e){var t,r,o,n;if(null==e)e=40;return t=new ActionDescriptor,n=new ActionReference,n.putClass(charIDToTypeID("AdjL")),t.putReference(charIDToTypeID("null"),n),r=new ActionDescriptor,o=new ActionDescriptor,o.putInteger(charIDToTypeID("Lvls"),e),r.putObject(charIDToTypeID("Type"),charIDToTypeID("Pstr"),o),t.putObject(charIDToTypeID("Usng"),charIDToTypeID("AdjL"),r),executeAction(charIDToTypeID("Mk  "),t,DialogModes.NO),this},r.prototype.exportAsPng=function(e,t){var r;return r=new ExportOptionsSaveForWeb,r.PNG8=!1,r.transparency=!0,r.format=SaveDocumentType.PNG,this.getObj().exportDocument(new File(""+t+"/"+e+".png"),ExportType.SAVEFORWEB,r),this},r.prototype.hasBackgroundLayer=function(){var e,t;for(t=0,e=this.getObj();t<e.layers.length;){if(e.layers[t].isBackgroundLayer)return!0;t++};return!1},r.prototype.updateLayers=function(){var e,t,r,o,n;if(o=this,this._artLayers=[],this._layerSets=[],e=this.getNumLayers(),0===e)return this;for(n=this.hasBackgroundLayer()?0:1;e>=n;){switch(t=owlstars.photoshop.Layer.getLayerKind(e)){case owlstars.photoshop.Layer.KIND_GROUP:r=new owlstars.photoshop.LayerSet(e,t,o),o._layerSets.push(r),o=r;break;case owlstars.photoshop.Layer.KIND_TEXT:case owlstars.photoshop.Layer.KIND_SHAPE:case owlstars.photoshop.Layer.KIND_NORMAL:case owlstars.photoshop.Layer.KIND_SMART_OBJECT:o._artLayers.push(new owlstars.photoshop.ArtLayer(e,t,o));break;case owlstars.photoshop.Layer.KIND_SECTION_END:o=o.getParent()};e--};return this},r.prototype.suspendHistory=function(e,t){var r;return r=Array.prototype.slice.call(arguments,2),owlstars.photoshop.Document._suspendHistoryObject={args:r,callback:t},this.getObj().suspendHistory(e,"owlstars.photoshop.Document._suspendHistoryCallback()"),this},r.prototype._getDocumentDescriptor=function(){var e;return e=new ActionReference,e.putIdentifier(charIDToTypeID("Dcmn"),this.getId()),executeActionGet(e)},r._suspendHistoryCallback=function(){var e;return e=owlstars.photoshop.Document._suspendHistoryObject,e.callback.apply(this,e.args)},r}(owlstars.photoshop.LayerSet),owlstars.photoshop.Preferences=function(){function e(e){this._obj=e};return e.prototype._defaults={},e.prototype._obj=null,e.prototype.get=function(e){return this._obj[e]},e.prototype.set=function(e,t){if(null==this._defaults[e])this._defaults[e]=this._obj[e];return this._obj[e]=t,this},e.prototype.restore=function(){var e,t,r;r=this._defaults;for(e in r)t=r[e],this._obj[e]=t,delete this._defaults[e];return this},e}(),owlstars.Photoshop=function(){function e(e){this._obj=e};return e._instance=void 0,e.prototype._obj=null,e.prototype._preferences=null,e.getInstance=function(){var e;return null!=(e=owlstars.Photoshop)._instance?e._instance:e._instance=new owlstars.Photoshop(app)},e.prototype.getObj=function(){return this._obj},e.prototype.addDocument=function(e,t,r){var o,n;return n=this.getObj().documents.add(t,r,72,e,NewDocumentMode.RGB),o=new owlstars.photoshop.Document(n),this.setActiveDocument(o),o},e.prototype.getNumDocuments=function(){return this.getObj().documents.length},e.prototype.getDocument=function(e){return new owlstars.photoshop.Document(this.getObj().documents[e])},e.prototype.getActiveDocument=function(){return new owlstars.photoshop.Document(this.getObj().activeDocument)},e.prototype.getActiveDocumentIndex=function(){var e,t,r,o,n,s;for(e=this.getObj().activeDocument,s=this.getObj().documents,t=o=0,n=s.length;n>o;t=++o)if(r=s[t],r===e)return t},e.prototype.setActiveDocument=function(e){return this.getObj().activeDocument=e.getObj(),this},e.prototype.getPreferences=function(){var e;return null!=(e=owlstars.Photoshop)._preferences?e._preferences:e._preferences=new owlstars.photoshop.Preferences(this.getObj().preferences)},e.prototype.getBackgroundColor=function(){return this.getObj().backgroundColor.rgb.hexValue},e.prototype.setBackgroundColor=function(e){return this.getObj().backgroundColor.rgb.hexValue=e,this},e}()}).call(this);
var spriteowl={compiler:{},utils:{}};(function(){var e,t={}.hasOwnProperty,i=function(e,i){function r(){this.constructor=e};for(var n in i)if(t.call(i,n))e[n]=i[n];return r.prototype=i.prototype,e.prototype=new r,e.__super__=i.prototype,e};spriteowl.utils.CSUtil=function(){function e(){};return e.toObject=function(e){var t,i,r;i={};for(t in e)r=e[t],i[t]=r;return i},e}(),spriteowl.utils.ClassUtil=function(){function t(){};return t.getClassInstance=function(t,i){var r,n;if(r=e,n=t.split(/[\[\]\.]+/),""===n[n.length-1])n.pop();for(;n.length&&null!=r&&_.isObject(r);)r=r[n.shift()];if(n.length||!_.isObject(n))throw new Error("Could not create instance from "+t);return new r(i)},t.getObjectClass=function(e){var t;if(null==e||!e.constructor||null==e.constructor.toString)return void 0;if(t=e.constructor.toString().match(/function\s*(\w+)/),t&&2===t.length)return t[1];else return void 0},t}(),spriteowl.utils.FileUtil=function(){function e(){};return e.write=function(e,t){var i;if(i=new File(e),i.encoding="UTF-8",i.lineFeed="unix",i.exists)i.remove();return i.open("w"),i.write(t.toString()),i.close(),!0},e}(),spriteowl.utils.StringUtil=function(){function e(){};return e.replace=function(e,t,i,r){var n,o;if(null==i)i=null;if(null==r)r=null;if(null==i)i=function(e){return e};if(null==r)r=function(e){return e};for(n in e)o=e[n],t=t.replace(new RegExp(i(n),"g"),r(o));return t},e}(),spriteowl.compiler.Base=function(){function e(e){if(this.options=e,this.level=0,this.namespace=[],null==this.extension)throw new Error("Syntax implementation must define extension!")};return e.prototype.level=null,e.prototype.namespace=null,e.prototype.options=null,e.prototype.renderCommentBlock=function(e){var t,i;e=e.split("\n");for(t in e)i=e[t],e[t]=i?"// "+i:"//";return e.join("\n")+"\n"},e.prototype.renderLayerSetComment=function(e,t){return this._indent("- "+e.getSanitizedName()+"/",t)},e.prototype.renderArtLayerComment=function(e,t){return this._indent("- "+e.getSanitizedName(),t)},e.prototype.renderDocStart=function(){return!1},e.prototype.renderBeforeLayerSet=function(){return!1},e.prototype.renderBeforeArtLayer=function(){return!1},e.prototype.renderArtLayer=function(){return!1},e.prototype.renderAfterArtLayer=function(){return!1},e.prototype.renderInbetweenArtLayers=function(){return!1},e.prototype.renderInbetweenLayerSets=function(){return!1},e.prototype.renderAfterLayerSet=function(){return!1},e.prototype.renderDocEnd=function(){return!1},e.prototype._getNamespace=function(e){var t,i;return i=function(){var i;for(i=[];null!=e;)t=e.getSanitizedName(),e=e.getParent(),i.push(t);return i}(),i.reverse(),i},e.prototype._formatLine=function(e,t){var i;if(null==t)t=0;if(0>t)this.level+=t;if(i=e?this._indent(e,this.level):"",t>0)this.level+=t;return i},e.prototype._indent=function(e,t){if(null==t)t=0;return _.str.repeat("  ",t)+e+this._newLine()},e.prototype._newLine=function(){return"\n"},e}(),spriteowl.compiler.Css=function(e){function t(){return t.__super__.constructor.apply(this,arguments)};return i(t,e),t.prototype.extension="css",t.prototype.renderDocComment=function(e){var t,i;return i="",t=e.getSanitizedName(),i+=this._formatLine("To change the location of your sprite, string replace:\n"),i+=this._formatLine('url("'+t+'.png") to url("path/to/'+t+'.png")')},t.prototype.renderDocStart=function(e){var t,i,r,n,o,s;for(r="",i=[],s=e.getAllWorkingArtLayers(),n=0,o=s.length;o>n;n++)t=s[n],i.push(this._getNamespace(t).join("-"));if(r+=this._formatLine("."+i.join(",.")+" {",1),r+=this._formatLine('background-image: url("'+e.getSanitizedName()+'.png");'),r+=this._formatLine("background-repeat: no-repeat;"),r+=this._formatLine("}",-1),this.options.retina)r+=this._formatLine("@media only screen and (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3/2), (-webkit-min-device-pixel-ratio: 1.5), (min-device-pixel-ratio: 1.5), (min-resolution: 144dpi), (min-resolution: 1.5dppx) {",1),r+=this._formatLine("."+i.join(",.")+" {",1),r+=this._formatLine('background-image: url("'+e.getSanitizedName()+'@2x.png");'),r+=this._formatLine("background-size: "+e.getWidthUnit()+" "+e.getHeightUnit()+";"),r+=this._formatLine("}",-1),r+=this._formatLine("}",-1);return r+=this._newLine()},t.prototype.renderBeforeLayerSet=function(e){return this.namespace.push(e.getSanitizedName()),!1},t.prototype.renderArtLayer=function(e,t){var i,r;if(i="",this.namespace.push(e.getSanitizedName()),r=this._renderClasses(e,t))i+=r;return this.namespace.pop(),i},t.prototype.renderAfterArtLayer=function(){return this._newLine()},t.prototype.renderAfterLayerSet=function(){if(this.namespace.length>0)this.namespace.pop();return!1},t.prototype.renderCommentBlock=function(e){var t,i;e=e.split("\n");for(t in e)i=e[t],e[t]=i?" * "+i:" *";return"/*\n"+e.join("\n")+"\n */\n"},t.prototype._renderClasses=function(e){var t,i,r,n,o,s;return r="",o=e.getXUnit(),s=e.getYUnit(),n=e.getWidthUnit(),t=e.getHeightUnit(),i=this.namespace.join("-"),r+=this._formatLine("."+i+"-width {",1),r+=this._formatLine("width: "+n+";"),r+=this._formatLine("}",-1),r+=this._formatLine("."+i+"-height {",1),r+=this._formatLine("height: "+t+";"),r+=this._formatLine("}",-1),r+=this._formatLine("."+i+"-size {",1),r+=this._formatLine("width: "+n+";"),r+=this._formatLine("height: "+t+";"),r+=this._formatLine("}",-1),r+=this._formatLine("."+i+"-position {",1),r+=this._formatLine("background-position: "+o+" "+s+";"),r+=this._formatLine("}",-1),r+=this._formatLine("."+i+" {",1),r+=this._formatLine("width: "+n+";"),r+=this._formatLine("height: "+t+";"),r+=this._formatLine("background-position: "+o+" "+s+";"),r+=this._formatLine("}",-1)},t}(spriteowl.compiler.Base),spriteowl.compiler.Less=function(e){function t(){return t.__super__.constructor.apply(this,arguments)};return i(t,e),t.prototype.extension="less",t.prototype.renderDocComment=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("Please define the location for your image source:"),i+=this._newLine(),i+=this._formatLine("@"+t+'-sheet-image: url("'+t+'.png");'),this.options.retina)i+=this._formatLine("@"+t+'-sheet-image-2x: url("'+t+'@2x.png");');return i},t.prototype.renderDocStart=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("@"+t+"-sheet-width: "+e.getWidthUnit()+";"),i+=this._formatLine("@"+t+"-sheet-height: "+e.getHeightUnit()+";"),i+=this._formatLine("@"+t+'-sheet-image: url("'+t+'.png");'),this.options.retina)i+=this._formatLine("@"+t+'-sheet-image-2x: url("'+t+'@2x.png");'),i+=this._formatLine("@"+t+"-sheet: @"+t+"-sheet-width @"+t+"-sheet-height @"+t+"-sheet-image @"+t+"-sheet-image-2x "+t+";");else i+=this._formatLine("@"+t+"-sheet: @"+t+"-sheet-width @"+t+"-sheet-height @"+t+"-sheet-image "+t+";");if(i+=this._newLine(),i+=this._formatLine("."+t+"-element() {",1),i+=this._formatLine("background-image: @"+t+"-sheet-image;"),i+=this._formatLine("background-repeat: no-repeat;"),this.options.retina)i+=this._formatLine("@media only screen and (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3/2), (-webkit-min-device-pixel-ratio: 1.5), (min-device-pixel-ratio: 1.5), (min-resolution: 144dpi), (min-resolution: 1.5dppx) {",1),i+=this._formatLine("background-image: @"+t+"-sheet-image-2x;"),i+=this._formatLine("background-size: @"+t+"-sheet-width @"+t+"-sheet-height;"),i+=this._formatLine("}",-1);return i+=this._formatLine("}",-1),i+=this._formatLine("."+t+"-element {",1),i+=this._formatLine("."+t+"-element();"),i+=this._formatLine("}",-1),i+=this._newLine()},t.prototype.renderBeforeLayerSet=function(e){var t;return t=e.getSanitizedName(),this.namespace.push(t),!1},t.prototype.renderArtLayer=function(e,t){var i,r;if(i="",this.namespace.push(e.getSanitizedName()),r=this._renderClasses(e,t))i+=r;return this.namespace.pop(),i},t.prototype.renderAfterArtLayer=function(){return this._newLine()},t.prototype.renderAfterLayerSet=function(){if(this.namespace.length>0)this.namespace.pop();return!1},t.prototype._renderClasses=function(e,t){var i,r,n,o,s,a;return n="",s=e.getXUnit(),a=e.getYUnit(),o=e.getWidthUnit(),i=e.getHeightUnit(),r=this.namespace.join("-"),n+=this._formatLine("@"+r+"-x: "+s+";"),n+=this._formatLine("@"+r+"-y: "+a+";"),n+=this._formatLine("@"+r+"-width: "+o+";"),n+=this._formatLine("@"+r+"-height: "+i+";"),n+=this._formatLine("@"+r+": @"+r+"-x @"+r+"-y @"+r+"-width @"+r+"-height "+r+";"),n+=this._newLine(),n+=this._formatLine("."+r+"-width() {",1),n+=this._formatLine("width: @"+r+"-width;"),n+=this._formatLine("}",-1),n+=this._formatLine("."+r+"-height() {",1),n+=this._formatLine("height: @"+r+"-height;"),n+=this._formatLine("}",-1),n+=this._formatLine("."+r+"-size() {",1),n+=this._formatLine("."+r+"-width();"),n+=this._formatLine("."+r+"-height();"),n+=this._formatLine("}",-1),n+=this._formatLine("."+r+"-position() {",1),n+=this._formatLine("background-position: @"+r+"-x @"+r+"-y;"),n+=this._formatLine("}",-1),n+=this._formatLine("."+r+"-adjust() {",1),n+=this._formatLine("."+r+"-size();"),n+=this._formatLine("."+r+"-position();"),n+=this._formatLine("}",-1),n+=this._formatLine("."+r+"() {",1),n+=this._formatLine("."+r+"-adjust();"),n+=this._formatLine("&:extend(."+t.getSanitizedName()+"-element);"),n+=this._formatLine("}",-1),n+=this._formatLine(".less-sprite-element("+r+") {",1),n+=this._formatLine("."+r+"();"),n+=this._formatLine("}",-1)},t}(spriteowl.compiler.Base),spriteowl.compiler.Sass=function(e){function t(){return t.__super__.constructor.apply(this,arguments)};return i(t,e),t.prototype.extension="sass",t.prototype.renderDocComment=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("Please define the location for your image source:"),i+=this._newLine(),i+=this._formatLine("$"+t+'-sheet-image: url("'+t+'.png")'),this.options.retina)i+=this._formatLine("$"+t+'-sheet-image-2x: url("'+t+'@2x.png")');return i},t.prototype.renderDocStart=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("$"+t+"-sheet-width: "+e.getWidthUnit()+" !default"),i+=this._formatLine("$"+t+"-sheet-height: "+e.getHeightUnit()+" !default"),i+=this._formatLine("$"+t+'-sheet-image: url("'+t+'.png") !default'),this.options.retina)i+=this._formatLine("$"+t+'-sheet-image-2x: url("'+t+'@2x.png") !default'),i+=this._formatLine("$"+t+"-sheet: $"+t+"-sheet-width $"+t+"-sheet-height $"+t+"-sheet-image $"+t+"-sheet-image-2x "+t+" !default");else i+=this._formatLine("$"+t+"-sheet: $"+t+"-sheet-width $"+t+"-sheet-height $"+t+"-sheet-image "+t+" !default");if(i+=this._newLine(),i+=this._formatLine("="+t+"-element()",1),i+=this._formatLine("background-image: $"+t+"-sheet-image"),i+=this._formatLine("background-repeat: no-repeat"),this.options.retina)i+=this._formatLine("@media only screen and (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3/2), (-webkit-min-device-pixel-ratio: 1.5), (min-device-pixel-ratio: 1.5), (min-resolution: 144dpi), (min-resolution: 1.5dppx)",1),i+=this._formatLine("background-image: $"+t+"-sheet-image-2x"),i+=this._formatLine("background-size: $"+t+"-sheet-width $"+t+"-sheet-height"),i+=this._formatLine("",-1);return i+=this._formatLine("",-1),i+=this._formatLine("%"+t+"-element",1),i+=this._formatLine("+"+t+"-element()"),i+=this._formatLine("",-1),i+=this._newLine()},t.prototype.renderBeforeLayerSet=function(e){var t;return t=e.getSanitizedName(),this.namespace.push(t),!1},t.prototype.renderArtLayer=function(e,t){var i,r;if(i="",this.namespace.push(e.getSanitizedName()),r=this._renderClasses(e,t))i+=r;return this.namespace.pop(),i},t.prototype.renderAfterArtLayer=function(){return this._newLine()},t.prototype.renderAfterLayerSet=function(){if(this.namespace.length>0)this.namespace.pop();return!1},t.prototype._renderClasses=function(e,t){var i,r,n,o,s,a;return n="",s=e.getXUnit(),a=e.getYUnit(),o=e.getWidthUnit(),i=e.getHeightUnit(),r=this.namespace.join("-"),n+=this._formatLine("$"+r+"-x: "+s+" !default"),n+=this._formatLine("$"+r+"-y: "+a+" !default"),n+=this._formatLine("$"+r+"-width: "+o+" !default"),n+=this._formatLine("$"+r+"-height: "+i+" !default"),n+=this._formatLine("$"+r+": $"+r+"-x $"+r+"-y $"+r+"-width $"+r+"-height "+r+" !default"),n+=this._newLine(),n+=this._formatLine("="+r+"-width()",1),n+=this._formatLine("width: $"+r+"-width"),n+=this._formatLine("",-1),n+=this._formatLine("%"+r+"-width",1),n+=this._formatLine("+"+r+"-width()"),n+=this._formatLine("",-1),n+=this._formatLine("="+r+"-height()",1),n+=this._formatLine("height: $"+r+"-height"),n+=this._formatLine("",-1),n+=this._formatLine("%"+r+"-height",1),n+=this._formatLine("+"+r+"-height()"),n+=this._formatLine("",-1),n+=this._formatLine("="+r+"-size()",1),n+=this._formatLine("+"+r+"-width()"),n+=this._formatLine("+"+r+"-height()"),n+=this._formatLine("",-1),n+=this._formatLine("%"+r+"-size",1),n+=this._formatLine("+"+r+"-size()"),n+=this._formatLine("",-1),n+=this._formatLine("="+r+"-position()",1),n+=this._formatLine("background-position: $"+r+"-x $"+r+"-y"),n+=this._formatLine("",-1),n+=this._formatLine("%"+r+"-position",1),n+=this._formatLine("+"+r+"-position()"),n+=this._formatLine("",-1),n+=this._formatLine("="+r+"-adjust()",1),n+=this._formatLine("+"+r+"-size()"),n+=this._formatLine("+"+r+"-position()"),n+=this._formatLine("",-1),n+=this._formatLine("%"+r+"-adjust",1),n+=this._formatLine("+"+r+"-adjust()"),n+=this._formatLine("",-1),n+=this._formatLine("="+r+"()",1),n+=this._formatLine("+"+r+"-adjust()"),n+=this._formatLine("@extend %"+t.getSanitizedName()+"-element"),n+=this._formatLine("",-1),n+=this._formatLine("%"+r,1),n+=this._formatLine("+"+r+"()"),n+=this._formatLine("",-1)},t}(spriteowl.compiler.Base),spriteowl.compiler.Scss=function(e){function t(){return t.__super__.constructor.apply(this,arguments)};return i(t,e),t.prototype.extension="scss",t.prototype.renderDocComment=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("Please define the location for your image source:"),i+=this._newLine(),i+=this._formatLine("$"+t+'-sheet-image: url("'+t+'.png");'),this.options.retina)i+=this._formatLine("$"+t+'-sheet-image-2x: url("'+t+'@2x.png");');return i},t.prototype.renderDocStart=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("$"+t+"-sheet-width: "+e.getWidthUnit()+" !default;"),i+=this._formatLine("$"+t+"-sheet-height: "+e.getHeightUnit()+" !default;"),i+=this._formatLine("$"+t+'-sheet-image: url("'+t+'.png") !default;'),this.options.retina)i+=this._formatLine("$"+t+'-sheet-image-2x: url("'+t+'@2x.png") !default;'),i+=this._formatLine("$"+t+"-sheet: $"+t+"-sheet-width $"+t+"-sheet-height $"+t+"-sheet-image $"+t+"-sheet-image-2x "+t+" !default;");else i+=this._formatLine("$"+t+"-sheet: $"+t+"-sheet-width $"+t+"-sheet-height $"+t+"-sheet-image "+t+" !default;");if(i+=this._newLine(),i+=this._formatLine("@mixin "+t+"-element() {",1),i+=this._formatLine("background-image: $"+t+"-sheet-image;"),i+=this._formatLine("background-repeat: no-repeat;"),this.options.retina)i+=this._formatLine("@media only screen and (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3/2), (-webkit-min-device-pixel-ratio: 1.5), (min-device-pixel-ratio: 1.5), (min-resolution: 144dpi), (min-resolution: 1.5dppx) {",1),i+=this._formatLine("background-image: $"+t+"-sheet-image-2x;"),i+=this._formatLine("background-size: $"+t+"-sheet-width $"+t+"-sheet-height;"),i+=this._formatLine("}",-1);return i+=this._formatLine("}",-1),i+=this._formatLine("%"+t+"-element {",1),i+=this._formatLine("@include "+t+"-element();"),i+=this._formatLine("}",-1),i+=this._newLine()},t.prototype.renderBeforeLayerSet=function(e){var t;return t=e.getSanitizedName(),this.namespace.push(t),!1},t.prototype.renderArtLayer=function(e,t){var i,r;if(i="",this.namespace.push(e.getSanitizedName()),r=this._renderClasses(e,t))i+=r;return this.namespace.pop(),i},t.prototype.renderAfterArtLayer=function(){return this._newLine()},t.prototype.renderAfterLayerSet=function(){if(this.namespace.length>0)this.namespace.pop();return!1},t.prototype._renderClasses=function(e,t){var i,r,n,o,s,a;return n="",s=e.getXUnit(),a=e.getYUnit(),o=e.getWidthUnit(),i=e.getHeightUnit(),r=this.namespace.join("-"),n+=this._formatLine("$"+r+"-x: "+s+" !default;"),n+=this._formatLine("$"+r+"-y: "+a+" !default;"),n+=this._formatLine("$"+r+"-width: "+o+" !default;"),n+=this._formatLine("$"+r+"-height: "+i+" !default;"),n+=this._formatLine("$"+r+": $"+r+"-x $"+r+"-y $"+r+"-width $"+r+"-height "+r+" !default;"),n+=this._newLine(),n+=this._formatLine("@mixin "+r+"-width() {",1),n+=this._formatLine("width: $"+r+"-width;"),n+=this._formatLine("}",-1),n+=this._formatLine("%"+r+"-width {",1),n+=this._formatLine("@include "+r+"-width();"),n+=this._formatLine("}",-1),n+=this._formatLine("@mixin "+r+"-height() {",1),n+=this._formatLine("height: $"+r+"-height;"),n+=this._formatLine("}",-1),n+=this._formatLine("%"+r+"-height {",1),n+=this._formatLine("@include "+r+"-height();"),n+=this._formatLine("}",-1),n+=this._formatLine("@mixin "+r+"-size() {",1),n+=this._formatLine("@include "+r+"-width();"),n+=this._formatLine("@include "+r+"-height();"),n+=this._formatLine("}",-1),n+=this._formatLine("%"+r+"-size {",1),n+=this._formatLine("@include "+r+"-size();"),n+=this._formatLine("}",-1),n+=this._formatLine("@mixin "+r+"-position() {",1),n+=this._formatLine("background-position: $"+r+"-x $"+r+"-y;"),n+=this._formatLine("}",-1),n+=this._formatLine("%"+r+"-position {",1),n+=this._formatLine("@include "+r+"-position();"),n+=this._formatLine("}",-1),n+=this._formatLine("@mixin "+r+"-adjust() {",1),n+=this._formatLine("@include "+r+"-size();"),n+=this._formatLine("@include "+r+"-position();"),n+=this._formatLine("}",-1),n+=this._formatLine("%"+r+"-adjust {",1),n+=this._formatLine("@include "+r+"-adjust();"),n+=this._formatLine("}",-1),n+=this._formatLine("@mixin "+r+"() {",1),n+=this._formatLine("@include "+r+"-adjust();"),n+=this._formatLine("@extend %"+t.getSanitizedName()+"-element;"),n+=this._formatLine("}",-1),n+=this._formatLine("%"+r+" {",1),n+=this._formatLine("@include "+r+"();"),n+=this._formatLine("}",-1)},t}(spriteowl.compiler.Base),spriteowl.compiler.Stylus=function(e){function t(){return t.__super__.constructor.apply(this,arguments)};return i(t,e),t.prototype.extension="styl",t.prototype.renderDocComment=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("Please define the location for your image source:"),i+=this._newLine(),i+=this._formatLine("$"+t+'-sheet-image = url("'+t+'.png")'),this.options.retina)i+=this._formatLine("$"+t+'-sheet-image-2x = url("'+t+'@2x.png")');return i},t.prototype.renderDocStart=function(e){var t,i;if(i="",t=e.getSanitizedName(),i+=this._formatLine("$"+t+"-sheet-width ?= "+e.getWidthUnit()),i+=this._formatLine("$"+t+"-sheet-height ?= "+e.getHeightUnit()),i+=this._formatLine("$"+t+'-sheet-image ?= url("'+t+'.png")'),this.options.retina)i+=this._formatLine("$"+t+'-sheet-image-2x ?= url("'+t+'@2x.png")'),i+=this._formatLine("$"+t+"-sheet ?= $"+t+"-sheet-width $"+t+"-sheet-height $"+t+"-sheet-image-2x $"+t+"-sheet-image-2x "+t);else i+=this._formatLine("$"+t+"-sheet ?= $"+t+"-sheet-width $"+t+"-sheet-height $"+t+"-sheet-image "+t);if(i+=this._newLine(),i+=this._formatLine(""+t+"-element()",1),i+=this._formatLine("background-image: $"+t+"-sheet-image"),i+=this._formatLine("background-repeat: no-repeat"),this.options.retina)i+=this._formatLine("@media only screen and (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3/2), (-webkit-min-device-pixel-ratio: 1.5), (min-device-pixel-ratio: 1.5), (min-resolution: 144dpi), (min-resolution: 1.5dppx)",1),i+=this._formatLine("background-image: $"+t+"-sheet-image-2x"),i+=this._formatLine("background-size: $"+t+"-sheet-width $"+t+"-sheet-height"),i+=this._formatLine("",-1);return i+=this._formatLine("",-1),i+=this._formatLine("$"+t+"-element",1),i+=this._formatLine("sprite-element()"),i+=this._formatLine("",-1),i+=this._newLine()},t.prototype.renderBeforeLayerSet=function(e){var t;return t=e.getSanitizedName(),this.namespace.push(t),!1},t.prototype.renderArtLayer=function(e,t){var i,r;if(i="",this.namespace.push(e.getSanitizedName()),r=this._renderClasses(e,t))i+=r;return this.namespace.pop(),i},t.prototype.renderAfterArtLayer=function(){return this._newLine()},t.prototype.renderAfterLayerSet=function(){if(this.namespace.length>0)this.namespace.pop();return!1},t.prototype._renderClasses=function(e,t){var i,r,n,o,s,a;return n="",s=e.getXUnit(),a=e.getYUnit(),o=e.getWidthUnit(),i=e.getHeightUnit(),r=this.namespace.join("-"),n+=this._formatLine("$"+r+"-x ?= "+s),n+=this._formatLine("$"+r+"-y ?= "+a),n+=this._formatLine("$"+r+"-width ?= "+o),n+=this._formatLine("$"+r+"-height ?= "+i),n+=this._formatLine("$"+r+" ?= $"+r+"-x $"+r+"-y $"+r+"-width $"+r+"-height "+r),n+=this._newLine(),n+=this._formatLine(""+r+"-width()",1),n+=this._formatLine("width: $"+r+"-width"),n+=this._formatLine("",-1),n+=this._formatLine("$"+r+"-width",1),n+=this._formatLine(""+r+"-width()"),n+=this._formatLine("",-1),n+=this._formatLine(""+r+"-height()",1),n+=this._formatLine("height: $"+r+"-height"),n+=this._formatLine("",-1),n+=this._formatLine("$"+r+"-height",1),n+=this._formatLine(""+r+"-height()"),n+=this._formatLine("",-1),n+=this._formatLine(""+r+"-size()",1),n+=this._formatLine(""+r+"-width()"),n+=this._formatLine(""+r+"-height()"),n+=this._formatLine("",-1),n+=this._formatLine("$"+r+"-size",1),n+=this._formatLine(""+r+"-size()"),n+=this._formatLine("",-1),n+=this._formatLine(""+r+"-position()",1),n+=this._formatLine("background-position: $"+r+"-x $"+r+"-y"),n+=this._formatLine("",-1),n+=this._formatLine("$"+r+"-position",1),n+=this._formatLine(""+r+"-position()"),n+=this._formatLine("",-1),n+=this._formatLine(""+r+"-adjust()",1),n+=this._formatLine(""+r+"-size()"),n+=this._formatLine(""+r+"-position()"),n+=this._formatLine("",-1),n+=this._formatLine("$"+r+"-adjust",1),n+=this._formatLine(""+r+"-adjust()"),n+=this._formatLine("",-1),n+=this._formatLine(""+r+"()",1),n+=this._formatLine(""+r+"-adjust()"),n+=this._formatLine("@extend $"+t.getSanitizedName()+"-element"),n+=this._formatLine("",-1),n+=this._formatLine("$"+r,1),n+=this._formatLine(""+r+"()"),n+=this._formatLine("",-1)},t}(spriteowl.compiler.Base),spriteowl.Compiler=function(e){function t(e){var t,i,r,n;if(null==e)e={};i={syntax:"Css",seperator:"-"},r=_.defaults(e,i),this.settings=_.pick(r,_.keys(i)),t=spriteowl.utils.ClassUtil,n=_.str.classify(this.settings.syntax),this.comp=t.getClassInstance("spriteowl.compiler."+n,r)};return i(t,e),t.prototype.comp=null,t.prototype.settings=null,t.prototype.renderDoc=function(e,t){var i,r,n;if(r="",r+=this.comp.renderCommentBlock(this._renderComment(e)),n=this.comp.renderDocStart(e))r+=n;if(n=this._renderLayerSet(e,e))r+=n;if(n=this.comp.renderDocEnd(e))r+=n;return i=this._export(r,e.getSanitizedName(),t)},t.prototype._renderComment=function(e){var t,i;if(t="",t+="Generated with Spriteowl (compiler version "+spriteowl.Facade.VERSION+")\n",t+="\n",i=this.comp.renderDocComment(e))t+=i;if(t+="\n",t+="--- Layers --------------------------------------------\n\n",i=this._renderLayerSetComment(e,0))t+=i;return t},t.prototype._renderLayerSetComment=function(e,t){var i,r;if(i="",r=this.comp.renderLayerSetComment(e,t))i+=r;if(r=this._renderArtLayersComment(e.getWorkingArtLayers(),t+1))i+=r;if(r=this._renderLayerSetsComment(e.getWorkingLayerSets(),t+1))i+=r;return i},t.prototype._renderLayerSetsComment=function(e,t){var i,r,n,o,s;for(r="",o=0,s=e.length;s>o;o++)if(i=e[o],n=this._renderLayerSetComment(i,t))r+=n;return r},t.prototype._renderArtLayersComment=function(e,t){var i,r,n,o,s;for(r="",o=0,s=e.length;s>o;o++)if(i=e[o],n=this._renderArtLayerComment(i,t))r+=n;return r},t.prototype._renderArtLayerComment=function(e,t){var i,r;if(i="",r=this.comp.renderArtLayerComment(e,t))i+=r;return i},t.prototype._renderLayerSet=function(e,t){var i,r;if(i="",r=this.comp.renderBeforeLayerSet(e,t))i+=r;if(r=this._renderArtLayers(e.getWorkingArtLayers(),t))i+=r;if(r=this._renderLayerSets(e.getWorkingLayerSets(),t))i+=r;if(r=this.comp.renderAfterLayerSet(e,t))i+=r;return i},t.prototype._renderLayerSets=function(e,t){var i,r,n,o,s,a;for(n="",i=s=0,a=e.length;a>s;i=++s){if(r=e[i],o=this._renderLayerSet(r,t))n+=o;if(i<e.length-1)if(o=this.comp.renderInbetweenLayerSets(t))n+=o};return n},t.prototype._renderArtLayers=function(e,t){var i,r,n,o,s,a;for(n="",r=s=0,a=e.length;a>s;r=++s){if(i=e[r],o=this._renderArtLayer(i,t))n+=o;if(r<e.length-1)if(o=this.comp.renderInbetweenArtLayers(t))n+=o};return n},t.prototype._renderArtLayer=function(e,t){var i,r;if(i="",r=this.comp.renderBeforeArtLayer(e,t))i+=r;if(r=this.comp.renderArtLayer(e,t))i+=r;if(r=this.comp.renderAfterArtLayer(e,t))i+=r;return this.emit("renderedArtLayer"),i},t.prototype._export=function(e,t,i){var r;return r=""+i+"/"+t+"."+this.comp.extension,spriteowl.utils.FileUtil.write(r,e),this},t}(owlstars.event.Emitter),spriteowl.Document=function(){function e(e,t){this.app=e,this.doc=t,this.progress=new owlstars.palette.ProgressBar};return e.prototype.app=null,e.prototype.doc=null,e.prototype.progress=null,e.prototype.numLayers=0,e.prototype.processedLayers=0,e.prototype.exportLayers=function(e,t){var i,r,n,o,s,a,h;for(console.log("=== Spriteowl ======================="),console.time("Spriteowl"),this.processedLayers=0,this.numLayers=this.doc.getAllWorkingArtLayers().length-this.doc.getWorkingArtLayers().length,console.timeLap("Spriteowl","calculated layers"),this.progress.show("Relax! Doing some magic!"),console.timeLap("Spriteowl","added progress bar"),h=this.doc.getWorkingLayerSets(),s=0,a=h.length;a>s;s++)o=h[s],console.timeLap("Spriteowl","--------------------"),i=new spriteowl.Compiler(t),i.addListener("renderedArtLayer",function(e){return function(){return e.processedLayers++,e._updateProgress()}}(this)),n=o.getSanitizedName(),o.select().duplicateToNewDocument(n,n),r=this.app.getActiveDocument(),r.revealAll(),console.timeLap("Spriteowl","got temp doc"),r.getLayerSets()[0].ungroup(),r=this.app.getActiveDocument(),console.timeLap("Spriteowl","ungrouped temp doc"),r.suspendHistory("Spriteowl",this._exportLayerDoc,r,e,t,i),this.app.setActiveDocument(this.doc);return console.timeLap("Spriteowl","exported layers"),this.progress.close(),console.timeEnd("Spriteowl"),!0},e.prototype._exportLayerDoc=function(e,t,i,r){var n,o;if(console.timeLap("Spriteowl","exporting layer group"),n=e.getBackgroundLayer(),null!=n)n.select().setVisible(!1);if(console.timeLap("Spriteowl","got background layer"),o=e.getSanitizedName(),i.trim)e.trim(),console.timeLap("Spriteowl","trimmed png");if(i.retina)e.exportAsPng(""+o+"@2x",t),console.timeLap("Spriteowl","exported retina image"),e.setImageSize(50,50),console.timeLap("Spriteowl","downsized image");return e.rasterizeAllLayers(),e.updateLayers(),e.exportAsPng(o,t),console.timeLap("Spriteowl","exported retina image"),r.renderDoc(e,t),console.timeLap("Spriteowl","rendered layerDoc"),e.close(),this},e.prototype._updateProgress=function(){return this.progress.setProgress(Math.ceil(this.processedLayers/this.numLayers*100)),this},e.exportActiveDocumentLayers=function(e,t){var i,r;return i=owlstars.Photoshop.getInstance(),r=new spriteowl.Document(i,i.getActiveDocument()),r.exportLayers(e,t)},e}(),spriteowl.Facade=function(){function e(){};return e.VERSION="1.3.1",e.run=function(e,t,i){var r,n,o,s;if(null==e)e="css";if(null==t)t=!0;if(null==i)i=!1;if(o={seperator:"-",retina:t,syntax:e,trim:i},r=owlstars.Photoshop.getInstance(),n=r.getActiveDocument(),s=Folder.selectDialog("Please select the destination."),null==s)return!1;else return n.suspendHistory("Spriteowl!",spriteowl.Document.exportActiveDocumentLayers,s,o),!0},e}(),e=this}).call(this);